#pragma once
#include <Windows.h>
#include <TlHelp32.h>
#include <Psapi.h>
#include <string>
#include <cstdint>

class Process {
public:
    Process() = default;
    ~Process();

    bool attach(const std::wstring& processName);
    void detach();

    bool isAttached() const { return m_handle != nullptr; }
    HANDLE handle() const { return m_handle; }
    uintptr_t baseAddress() const { return m_baseAddress; }
    uintptr_t moduleSize() const { return m_moduleSize; }
    DWORD pid() const { return m_pid; }

private:
    DWORD findProcessId(const std::wstring& processName);
    uintptr_t getModuleBase();
    uintptr_t getModuleSize();

    HANDLE m_handle = nullptr;
    DWORD m_pid = 0;
    uintptr_t m_baseAddress = 0;
    uintptr_t m_moduleSize = 0;
};