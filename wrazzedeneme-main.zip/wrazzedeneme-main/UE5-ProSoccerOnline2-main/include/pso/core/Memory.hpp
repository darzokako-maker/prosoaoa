#pragma once
#include <Windows.h>
#include <cstdint>
#include <cstring>
#include <cstdlib>
#include <initializer_list>
#include <string>
#include <vector>
#include <algorithm>


class Memory {
public:
  explicit Memory(HANDLE processHandle) : m_handle(processHandle) {}

  template <typename T> T read(uintptr_t address) const {
    T value{};
    ReadProcessMemory(m_handle, reinterpret_cast<LPCVOID>(address), &value,
                      sizeof(T), nullptr);
    return value;
  }

  template <typename T> bool write(uintptr_t address, const T &value) const {
    return WriteProcessMemory(m_handle, reinterpret_cast<LPVOID>(address),
                              &value, sizeof(T), nullptr) != 0;
  }

  bool readBuffer(uintptr_t address, void *buffer, size_t size) const {
    return ReadProcessMemory(m_handle, reinterpret_cast<LPCVOID>(address),
                             buffer, size, nullptr) != 0;
  }

  // Follow a pointer chain: base -> [base + off1] -> [prev + off2] -> ...
  uintptr_t readChain(uintptr_t base,
                      std::initializer_list<uintptr_t> offsets) const {
    uintptr_t addr = base;
    auto it = offsets.begin();
    auto end = offsets.end();

    if (it == end)
      return addr;

    // All but the last offset: dereference pointer then add next offset
    for (; it != end - 1; ++it) {
      addr = read<uintptr_t>(addr + *it);
      if (addr == 0)
        return 0;
    }
    // Last offset: just add, don't dereference
    addr += *it;
    return addr;
  }

  // Read an FString: read the wchar_t* pointer at address, then read the string
  // data
  std::wstring readFString(uintptr_t address) const {
    // FString layout: wchar_t* Data (8 bytes), int32 Count (4), int32 Max (4)
    uintptr_t dataPtr = read<uintptr_t>(address);
    int32_t count = read<int32_t>(address + 8);

    if (dataPtr == 0 || count <= 0 || count > 256)
      return L"";

    std::wstring result(count, L'\0');
    ReadProcessMemory(m_handle, reinterpret_cast<LPCVOID>(dataPtr),
                      result.data(), count * sizeof(wchar_t), nullptr);

    // Remove null terminator if present
    if (!result.empty() && result.back() == L'\0')
      result.pop_back();

    return result;
  }

  // Convert wide string to narrow
  static std::string wideToNarrow(const std::wstring &wide) {
    if (wide.empty())
      return "";
    std::string narrow;
    narrow.reserve(wide.size());
    for (wchar_t c : wide) {
      narrow += static_cast<char>(c);
    }
    return narrow;
  }

  // ============================================================
  // AOB Pattern Scan (external process)
  // Scans remote memory for a byte pattern. '?' = wildcard byte.
  // ============================================================
  uintptr_t FindPattern(uintptr_t startAddress, uintptr_t size,
                        const char *signature) const {
    auto patternToByte = [](const char *pattern) {
      std::vector<int> bytes;
      const char *start = pattern;
      const char *end = pattern + std::strlen(pattern);
      for (const char *current = start; current < end; ++current) {
        if (*current == '?') {
          ++current;
          if (current < end && *current == '?')
            ++current;
          bytes.push_back(-1);
        } else {
          bytes.push_back(
              static_cast<int>(std::strtoul(current,
                                            const_cast<char **>(&current), 16)));
        }
      }
      return bytes;
    };

    auto patternBytes = patternToByte(signature);
    size_t patternSize = patternBytes.size();
    if (patternSize == 0)
      return 0;

    const size_t chunkSize = 4096;
    std::vector<uint8_t> buffer(chunkSize + patternSize);

    for (uintptr_t offset = 0; offset < size; offset += chunkSize) {
      uintptr_t chunkStart = startAddress + offset;
      uintptr_t chunkRemaining = size - offset;
      size_t chunkReadSize =
          static_cast<size_t>(std::min<uintptr_t>(chunkSize, chunkRemaining));

      SIZE_T read = 0;
      if (!ReadProcessMemory(m_handle, reinterpret_cast<LPCVOID>(chunkStart),
                             buffer.data(), chunkReadSize + patternSize,
                             &read) ||
          read == 0) {
        continue;
      }

      size_t usable = (read > patternSize) ? (read - patternSize) : 0;
      if (usable > chunkReadSize)
        usable = chunkReadSize;

      for (size_t i = 0; i < usable; ++i) {
        bool found = true;
        for (size_t j = 0; j < patternSize; ++j) {
          if (buffer[i + j] != static_cast<uint8_t>(patternBytes[j]) &&
              patternBytes[j] != -1) {
            found = false;
            break;
          }
        }
        if (found)
          return chunkStart + static_cast<uintptr_t>(i);
      }
    }
    return 0;
  }

private:
  HANDLE m_handle;
};