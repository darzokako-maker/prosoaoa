// ============================================================
// PSO Analyzer — DLL Injector
// Injects BypassDll.dll into ProSoccerOnline process
// ============================================================

#pragma once
#include <Windows.h>
#include <filesystem>
#include <iostream>
#include <string>


class DllInjector {
public:
  // Inject a DLL into a process by PID
  static bool Inject(DWORD processId, const std::wstring &dllPath) {
    // Verify DLL exists
    if (!std::filesystem::exists(dllPath)) {
      std::wcerr << L"[!] DLL not found: " << dllPath << std::endl;
      return false;
    }

    // Get absolute path
    std::wstring absolutePath = std::filesystem::absolute(dllPath).wstring();

    // Open target process
    HANDLE hProcess = OpenProcess(
        PROCESS_CREATE_THREAD | PROCESS_QUERY_INFORMATION |
            PROCESS_VM_OPERATION | PROCESS_VM_WRITE | PROCESS_VM_READ,
        FALSE, processId);

    if (!hProcess) {
      std::cerr << "[!] Failed to open process. Error: " << GetLastError()
                << std::endl;
      return false;
    }

    // Allocate memory in target process for DLL path
    size_t pathSize = (absolutePath.size() + 1) * sizeof(wchar_t);
    LPVOID remoteMem = VirtualAllocEx(hProcess, nullptr, pathSize,
                                      MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);

    if (!remoteMem) {
      std::cerr << "[!] VirtualAllocEx failed. Error: " << GetLastError()
                << std::endl;
      CloseHandle(hProcess);
      return false;
    }

    // Write DLL path to target process memory
    if (!WriteProcessMemory(hProcess, remoteMem, absolutePath.c_str(), pathSize,
                            nullptr)) {
      std::cerr << "[!] WriteProcessMemory failed. Error: " << GetLastError()
                << std::endl;
      VirtualFreeEx(hProcess, remoteMem, 0, MEM_RELEASE);
      CloseHandle(hProcess);
      return false;
    }

    // Get LoadLibraryW address
    HMODULE hKernel32 = GetModuleHandleW(L"kernel32.dll");
    if (!hKernel32) {
      VirtualFreeEx(hProcess, remoteMem, 0, MEM_RELEASE);
      CloseHandle(hProcess);
      return false;
    }

    FARPROC loadLibAddr = GetProcAddress(hKernel32, "LoadLibraryW");
    if (!loadLibAddr) {
      VirtualFreeEx(hProcess, remoteMem, 0, MEM_RELEASE);
      CloseHandle(hProcess);
      return false;
    }

    // Create remote thread to call LoadLibraryW with our DLL path
    HANDLE hThread = CreateRemoteThread(
        hProcess, nullptr, 0,
        reinterpret_cast<LPTHREAD_START_ROUTINE>(loadLibAddr), remoteMem, 0,
        nullptr);

    if (!hThread) {
      std::cerr << "[!] CreateRemoteThread failed. Error: " << GetLastError()
                << std::endl;
      VirtualFreeEx(hProcess, remoteMem, 0, MEM_RELEASE);
      CloseHandle(hProcess);
      return false;
    }

    // Wait for the thread to finish (DLL loaded)
    WaitForSingleObject(hThread, 10000);

    // Check if DLL was loaded successfully
    DWORD exitCode = 0;
    GetExitCodeThread(hThread, &exitCode);

    // Cleanup
    CloseHandle(hThread);
    VirtualFreeEx(hProcess, remoteMem, 0, MEM_RELEASE);
    CloseHandle(hProcess);

    if (exitCode == 0) {
      std::cerr << "[!] LoadLibraryW returned NULL - DLL load failed."
                << std::endl;
      return false;
    }

    std::cout << "[+] DLL injected successfully! Module handle: 0x" << std::hex
              << exitCode << std::dec << std::endl;
    return true;
  }

  // Find DLL path relative to the executable
  static std::wstring GetDllPath() {
    wchar_t exePath[MAX_PATH];
    GetModuleFileNameW(nullptr, exePath, MAX_PATH);

    std::filesystem::path p(exePath);
    std::filesystem::path dllPath = p.parent_path() / L"BypassDll.dll";
    return dllPath.wstring();
  }
};
