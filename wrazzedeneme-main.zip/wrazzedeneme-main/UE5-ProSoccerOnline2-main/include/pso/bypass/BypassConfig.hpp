#pragma once
#include <cstdint>

// ============================================================================
// Server-Side Bypass Configuration
// Offsets and signatures for ProcessEvent hook
// SDK: 5.4.4-0+UE5-ProSoccerOnline (Dumper-7)
// Updated: D:\text.txt (PSO_Offsets, 10 Kas 2026)
// ============================================================================

namespace BypassOffsets {

// Global offsets (RVA from module base)
constexpr uintptr_t GObjects = 0x7C85230;
constexpr uintptr_t GNames   = 0x7BCE540;

// AOB signatures — fallback when hardcoded offset is stale
constexpr const char* Sig_GWorld   = "48 8B 1D ? ? ? ? 48 85 DB 74 ? 41 B0 01";
constexpr const char* Sig_GObjects = "48 8B 05 ? ? ? ? 48 8B 0C C8 48 8D 04 D1";
constexpr const char* Sig_GNames   = "48 8D 0D ? ? ? ? E8 ? ? ? ? C6 05 ? ? ? ? 01";

// UObject layout
constexpr uintptr_t UObject_VTable = 0x00;
constexpr uintptr_t UObject_Class = 0x10;
constexpr uintptr_t UObject_Name = 0x18; // FName (ComparisonIndex at +0x00)

// UStruct layout
constexpr uintptr_t UStruct_SuperStruct = 0x40;
constexpr uintptr_t UStruct_PropertiesSize = 0x58;

// UFunction layout (extends UStruct)
// UFunction::FunctionFlags is at offset 0xB0 in UE5
constexpr uintptr_t UFunction_FunctionFlags = 0xB0;

// FNamePool / FNameEntry access
// FNamePool is at GNames address
// FNameEntry header: 2 bytes (uint16), then the string data
constexpr int32_t FNameStride = 2; // Entries are 2-byte aligned in blocks
constexpr int32_t FNameBlockBits = 16;
constexpr int32_t FNameBlockOffsetBits = 16;
constexpr int32_t FNameMaxBlockBits = 13;

// POV_Character_C / ASoccerPlayer_C class identification
constexpr int32_t POV_Character_ClassSize = 0x1EC0;

// POV_Character_C property offsets (match PSO_Offsets::ASoccerPlayer)
constexpr uintptr_t Stamina = 0x0CF8;
constexpr uintptr_t StaminaCooldown = 0x0D00;
constexpr uintptr_t HoldingKickChargePower = 0x0D58;

// CharacterMovement component
constexpr uintptr_t CharacterMovement = 0x0320; // ACharacter -> CMC* (updated)

// CharacterMovementComponent offsets
constexpr uintptr_t MaxWalkSpeed = 0x0248; // float (updated)
constexpr uintptr_t MaxAcceleration = 0x0258; // float (updated)

// AC counters
constexpr uintptr_t SpeedFailed = 0x1C18;
constexpr uintptr_t TouchDecelFailed = 0x1C20;
constexpr uintptr_t AccelerationFailed = 0x1C24;
constexpr uintptr_t MaxAccelerationFailed = 0x1C28;
constexpr uintptr_t TimelinesFailed = 0x1C2C;
constexpr uintptr_t CameraFailed = 0x1C30;
constexpr uintptr_t CallbacksFailed = 0x1C34;

} // namespace BypassOffsets

// ProcessEvent virtual function index in VTable
// In UE5, ProcessEvent is typically at vtable index 0x44 (68th entry)
// This may vary; we'll use pattern scanning to find it
constexpr int32_t PROCESSEVENT_VTABLE_INDEX = 0x44;

// Named shared memory for IPC between external tool and injected DLL
constexpr wchar_t* BYPASS_CONFIG_SECTION_NAME = L"\\BaseNamedObjects\\PSO_BypassConfig_v1";

// Magic value to validate shared config
constexpr uint32_t BYPASS_CONFIG_MAGIC = 0x50534F43; // "PSOC"

// ============================================================================
// Shared memory structure for communication between DLL and external tool
// ============================================================================
struct alignas(8) BypassSharedConfig {
  uint32_t magic = BYPASS_CONFIG_MAGIC;
  uint32_t version = 1;

  // Feature toggles
  bool staminaBypass = true;
  bool kickPowerBypass = true;
  bool speedBypass = true;
  bool acResetBypass = true;
  bool blockReduceStamina = true;

  // Values
  double staminaValue = 100.0;
  double kickPowerMultiplier = 3.0;
  double speedMultiplier = 1.35;
  double accelerationMultiplier = 1.35;

  // Safe limits
  double maxSafeSpeed = 1200.0;
  double maxSafeAcceleration = 4000.0;

  // Anti-cheat behavior
  int32_t acCounterJitterMax = 3; // 0 = always zero, >0 = random 0..N

  // Status (written by DLL, read by external tool)
  volatile bool hookInstalled = false;
  volatile int32_t hookCallCount = 0;
  volatile int32_t kicksIntercepted = 0;
  volatile int32_t staminaResetBlocked = 0;
  volatile int32_t speedSetsIntercepted = 0;

  // Original values (captured from server)
  double serverStamina = 0.0;
  double serverSpeed = 0.0;
  double serverAcceleration = 0.0;

private:
  // Padding to keep struct 8-byte aligned for shared memory
  uint8_t _pad[7];
};

// Parameter structures matching SDK dump
#pragma pack(push, 1)

struct KickSoccerBallParams {
  int32_t KickType;
  float KickPowerInput;
  float VerticalInput;
  float HorizontalInput;
};

struct HeaderSoccerBallParams {
  int32_t KickType;
  float KickPowerInput;
  float HorizontalInput;
};

struct SetStaminaClientParams {
  float Stamina_0;
};

struct SetSpeedAccelerationClientParams {
  float Speed;
  float Acceleration;
};

struct SetSprintingClientParams {
  bool Sprinting_0;
};

struct StartKickChargeHoldParams {
  int32_t HoldingKickChargeType_0;
  float HoldingKickChargePower_0;
  float HoldingKickChargeVerticalInput_0;
  float HoldingKickChargeHorizontalInput_0;
};

#pragma pack(pop)