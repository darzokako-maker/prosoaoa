#pragma once
#include <cstdint>

// ============================================================================
// Game-specific offsets extracted from SDK dump
// SDK: 5.4.4-0+UE5-ProSoccerOnline (Dumper-7)
// Updated: D:\text.txt (PSO_Offsets, 10 Kas 2026)
// ============================================================================

namespace Offsets {
// Global offsets (RVA from module base)
constexpr uintptr_t GObjects = 0x7C85230;
constexpr uintptr_t GNames   = 0x7BCE540;
constexpr uintptr_t GWorld   = 0x7E05898;

// AOB signatures — fallback when hardcoded offset is stale
constexpr const char* Sig_GWorld   = "48 8B 1D ? ? ? ? 48 85 DB 74 ? 41 B0 01";
constexpr const char* Sig_GObjects = "48 8B 05 ? ? ? ? 48 8B 0C C8 48 8D 04 D1";
constexpr const char* Sig_GNames   = "48 8D 0D ? ? ? ? E8 ? ? ? ? C6 05 ? ? ? ? 01";
} // namespace Offsets

// TUObjectArray (chunked) — used to iterate GObjects
namespace GObjects_Layout {
constexpr int32_t ElementsPerChunk = 0x10000;

// TUObjectArray layout:
// 0x00: FUObjectItem** Objects (pointer to chunk array)
// 0x10: int32 MaxElements
// 0x14: int32 NumElements
// 0x18: int32 MaxChunks
// 0x1C: int32 NumChunks
constexpr uintptr_t Objects = 0x00;
constexpr uintptr_t NumElements = 0x14;
constexpr uintptr_t NumChunks = 0x1C;

// FUObjectItem layout:
// 0x00: UObject* Object
// total size: 0x18
constexpr size_t ItemSize = 0x18;
} // namespace GObjects_Layout

// UObject (0x28 bytes)
namespace UObject_Off {
constexpr uintptr_t VTable = 0x00;
constexpr uintptr_t Flags = 0x08;
constexpr uintptr_t Index = 0x0C;
constexpr uintptr_t Class = 0x10; // UClass*
constexpr uintptr_t Name = 0x18;  // FName (8 bytes)
constexpr uintptr_t Outer = 0x20; // UObject*
} // namespace UObject_Off

// UStruct (extends UField which extends UObject)
namespace UStruct_Off {
constexpr uintptr_t SuperStruct = 0x40; // UStruct*
constexpr uintptr_t Children = 0x48;
constexpr uintptr_t ChildProperties = 0x50;
constexpr uintptr_t PropertiesSize = 0x58; // int32
} // namespace UStruct_Off

// UClass (extends UStruct)
namespace UClass_Off {
constexpr uintptr_t CastFlags = 0xD8;           // EClassCastFlags (uint64)
constexpr uintptr_t ClassDefaultObject = 0x110; // UObject*
} // namespace UClass_Off

// AActor inherits from UObject
// ACharacter base size = 0x0670 in this SDK

// POV_Character_C (BlueprintGeneratedClass)
// Total size: 0x1EC0 (extends ACharacter 0x0670)
// UStruct::Size (at 0x58) = total allocation size, not blueprint delta
namespace POV_Character {
constexpr int32_t ClassSize = 0x1EC0; // Total size used to identify the class

// Camera components (USpringArmComponent pointers)
constexpr uintptr_t OnestPersonCameraRoot = 0x0740;   // USpringArmComponent*
constexpr uintptr_t ThreerdPersonCameraRoot = 0x0750; // USpringArmComponent*

// Player state
constexpr uintptr_t Stamina = 0x0CF8;         // double
constexpr uintptr_t StaminaCooldown = 0x0D00; // bool
constexpr uintptr_t Sprinting = 0x0CF1;       // bool

// Camera settings
constexpr uintptr_t ThreerdPersonCameraDistance = 0x0D18; // double
constexpr uintptr_t ThreerdPersonCameraHeight = 0x0D20;   // double

// Player info
constexpr uintptr_t playerName = 0x0D38; // FString (16 bytes: ptr+count+max)
constexpr uintptr_t Team = 0x0D48;       // int32
constexpr uintptr_t Position = 0x0D4C;   // int32

// Kick
constexpr uintptr_t HoldingKickCharge = 0x0D50;      // bool
constexpr uintptr_t HoldingKickChargePower = 0x0D58; // double
constexpr uintptr_t KickCoolDown = 0x1B70;           // bool

// GK
constexpr uintptr_t GkModeActive = 0x1728;     // bool
constexpr uintptr_t GkPossessingBall = 0x172E; // bool

// Anti-cheat failed counters (int32 each)
constexpr uintptr_t SpeedFailed = 0x1C18;
constexpr uintptr_t TouchDecelFailed = 0x1C20;
constexpr uintptr_t AccelerationFailed = 0x1C24;
constexpr uintptr_t MaxAccelerationFailed = 0x1C28;
constexpr uintptr_t TimelinesFailed = 0x1C2C;
constexpr uintptr_t CameraFailed = 0x1C30;
constexpr uintptr_t CallbacksFailed = 0x1C34;
} // namespace POV_Character

// ASoccerPlayer_C (BlueprintGeneratedClass) — new class name from current SDK dump
// Property offsets match PSO_Offsets::ASoccerPlayer from D:\text.txt
namespace ASoccerPlayer {
constexpr int32_t ClassSize = 0x1EC0; // Total size used to identify the class (same layout)

constexpr uintptr_t FirstPersonCamera                = 0x0748; // UCameraComponent*
constexpr uintptr_t ThirdPersonCamera                = 0x0758; // UCameraComponent*
constexpr uintptr_t ThreerdPersonCameraDistance      = 0x0D18; // double
constexpr uintptr_t ThreerdPersonCameraHeight        = 0x0D20; // double
constexpr uintptr_t FreeLookActive                   = 0x0D01; // bool
constexpr uintptr_t FreeLookYaw                      = 0x0D08; // double
constexpr uintptr_t FreeLookPitch                    = 0x0D10; // double
constexpr uintptr_t FreeLookLocked                   = 0x1E10; // bool

constexpr uintptr_t AimHorizontal                    = 0x0CB8; // double
constexpr uintptr_t AimVertical                      = 0x0CC0; // double
constexpr uintptr_t HeadYaw                          = 0x0CC8; // double
constexpr uintptr_t HeadPitch                        = 0x0CD0; // double

constexpr uintptr_t SprintButtonPressed              = 0x0CF0; // bool
constexpr uintptr_t Sprinting                        = 0x0CF1; // bool
constexpr uintptr_t Stamina                          = 0x0CF8; // double
constexpr uintptr_t StaminaCooldown                  = 0x0D00; // bool
constexpr uintptr_t InTouchSlowdown                  = 0x1DF8; // bool

constexpr uintptr_t playerName                       = 0x0D38; // FString
constexpr uintptr_t Team                             = 0x0D48; // int32
constexpr uintptr_t Position                         = 0x0D4C; // int32

constexpr uintptr_t HoldingKickCharge                = 0x0D50; // bool
constexpr uintptr_t HoldingKickChargeApplied         = 0x0D51; // bool
constexpr uintptr_t HoldingKickChargeType            = 0x0D54; // int32
constexpr uintptr_t HoldingKickChargePower           = 0x0D58; // double
constexpr uintptr_t HoldingKickChargeVerticalInput   = 0x0D60; // double
constexpr uintptr_t HoldingKickChargeHorizontalInput = 0x0D68; // double
constexpr uintptr_t KickCoolDown                     = 0x1B70; // bool

constexpr uintptr_t GkModeActive                     = 0x1728; // bool
constexpr uintptr_t GkInTeamPenaltyBox               = 0x1729; // bool
constexpr uintptr_t GkPassBackRuleActive             = 0x172A; // bool
constexpr uintptr_t GkDiveExpended                   = 0x172D; // bool
constexpr uintptr_t GkPossessingBall                 = 0x172E; // bool
constexpr uintptr_t GkPossessedBall                  = 0x1730; // ASoccerBall_C*
constexpr uintptr_t GkDiveExpended                   = 0x172D; // bool

constexpr uintptr_t SlideTackleActive                = 0x1754; // bool
constexpr uintptr_t Offside                          = 0x1755; // bool
constexpr uintptr_t OffsideLocation                  = 0x1758; // FVector

constexpr uintptr_t SpeedFailed                      = 0x1C18; // int32
constexpr uintptr_t PlayerWasJustMoved               = 0x1C1C; // bool
constexpr uintptr_t TouchDecelFailed                 = 0x1C20; // int32
constexpr uintptr_t AccelerationFailed               = 0x1C24; // int32
constexpr uintptr_t MaxAccelerationFailed            = 0x1C28; // int32
constexpr uintptr_t TimelinesFailed                  = 0x1C2C; // int32
constexpr uintptr_t CameraFailed                     = 0x1C30; // int32
constexpr uintptr_t CallbacksFailed                  = 0x1C34; // int32
} // namespace ASoccerPlayer

// USpringArmComponent offsets (from Engine_classes.hpp)
namespace SpringArm {
constexpr uintptr_t TargetArmLength = 0x0298; // float
constexpr uintptr_t SocketOffset = 0x02A0;    // FVector (24 bytes, Z at +0x10)
constexpr uintptr_t TargetOffset = 0x02B8;    // FVector (24 bytes, Z at +0x10)
} // namespace SpringArm

// ACharacter -> CharacterMovement component pointer
namespace ACharacter_Off {
constexpr uintptr_t CharacterMovement = 0x0328; // UCharacterMovementComponent*
}

// UCharacterMovementComponent
namespace CharMovement {
constexpr uintptr_t MaxWalkSpeed =
    0x0248; // float (updated from SDK dump)
constexpr uintptr_t MaxAcceleration = 0x0258; // float
} // namespace CharMovement

// SoccerBall_C (BlueprintGeneratedClass)
// Total size: 0x0378
namespace SoccerBall {
constexpr int32_t PropertiesSize = 0x00E8;            // BP size
constexpr uintptr_t InteractionState = 0x0328;        // int32
constexpr uintptr_t PossessingCharacter = 0x0330;     // APOV_Character_C*
constexpr uintptr_t DropKickPowerMultiplier = 0x0350; // double
constexpr uintptr_t RollPowerMultiplier = 0x0358;     // double
constexpr uintptr_t ThrowPowerMultiplier = 0x0360;    // double
} // namespace SoccerBall