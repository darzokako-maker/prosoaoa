#pragma once
#include <cstdint>

// UE5.4 uses double for FVector components
struct FVector {
  double X = 0.0;
  double Y = 0.0;
  double Z = 0.0;
};

struct FRotator {
  double Pitch = 0.0;
  double Yaw = 0.0;
  double Roll = 0.0;
};

struct FName {
  int32_t ComparisonIndex = 0;
  uint32_t Number = 0;
};

// FString in-memory layout (for external reading)
struct FString {
  uintptr_t Data = 0; // wchar_t* pointer
  int32_t Count = 0;
  int32_t Max = 0;
};
