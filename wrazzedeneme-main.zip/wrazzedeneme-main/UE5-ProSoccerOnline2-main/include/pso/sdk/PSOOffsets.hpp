#pragma once
#include <cstdint>

// ============================================================================
// Game: Pro Soccer Online (5.4.4-0+UE5 | Shipping x64)
// Module: ProSoccerOnline-Win64-Shipping.exe
// Source: D:\text.txt (offset table, 10 Kas 2026)
// ============================================================================

namespace PSO_Offsets {

// ----------------------------------------------------------------------------
// 1. Global UE 5.4.4 Engine Pointers & AOB Signatures
//    Try hardcoded offset first; fall back to AOB pattern scan.
// ----------------------------------------------------------------------------
namespace Globals {
    constexpr uintptr_t GObjects = 0x7C85230; // FChunkedFixedUObjectArray
    constexpr uintptr_t GNames   = 0x7BCE540; // FNamePool
    constexpr uintptr_t GWorld   = 0x7E05898; // UWorld*

    // AOB signatures — used when hardcoded offset no longer resolves
    constexpr const char* Sig_GWorld   = "48 8B 1D ? ? ? ? 48 85 DB 74 ? 41 B0 01";
    constexpr const char* Sig_GObjects = "48 8B 05 ? ? ? ? 48 8B 0C C8 48 8D 04 D1";
    constexpr const char* Sig_GNames   = "48 8D 0D ? ? ? ? E8 ? ? ? ? C6 05 ? ? ? ? 01";
} // namespace Globals

// ----------------------------------------------------------------------------
// 2. Core Unreal Engine 5.4.4 Hierarchy (World -> Pawn -> Movement)
// ----------------------------------------------------------------------------
namespace Engine {
    // UWorld
    constexpr uintptr_t PersistentLevel          = 0x0030; // ULevel*
    constexpr uintptr_t NetDriver                = 0x0038; // UNetDriver*
    constexpr uintptr_t GameState                = 0x0160; // AGameStateBase*
    constexpr uintptr_t OwningGameInstance       = 0x01D8; // UGameInstance*

    // ULevel
    constexpr uintptr_t ActorsArray              = 0x00A0; // TArray<AActor*>
    constexpr uintptr_t ActorsCount              = 0x00A8; // int32

    // UGameInstance -> UPlayer
    constexpr uintptr_t LocalPlayers             = 0x0038; // TArray<ULocalPlayer*>
    constexpr uintptr_t PlayerController         = 0x0030; // APlayerController*

    // APlayerController
    constexpr uintptr_t PlayerCameraManager      = 0x0348; // APlayerCameraManager*
    constexpr uintptr_t AcknowledgedPawn         = 0x0338; // APawn* (Local ASoccerPlayer_C*)
    constexpr uintptr_t ControlRotation          = 0x0308; // FRotator (Pitch, Yaw, Roll - double)

    // AActor / APawn / ACharacter
    constexpr uintptr_t RootComponent            = 0x0198; // USceneComponent*
    constexpr uintptr_t PlayerState              = 0x02B0; // APlayerState*
    constexpr uintptr_t Mesh                     = 0x0318; // USkeletalMeshComponent*
    constexpr uintptr_t CharacterMovement        = 0x0320; // UCharacterMovementComponent*

    // USceneComponent
    constexpr uintptr_t RelativeLocation         = 0x0128; // FVector (double X, Y, Z)
    constexpr uintptr_t RelativeRotation         = 0x0140; // FRotator (double Pitch, Yaw, Roll)
    constexpr uintptr_t ComponentVelocity        = 0x0168; // FVector (double X, Y, Z)

    // UCharacterMovementComponent
    constexpr uintptr_t GravityScale             = 0x0170; // float
    constexpr uintptr_t MaxWalkSpeed             = 0x0248; // float
    constexpr uintptr_t MaxWalkSpeedCrouched     = 0x024C; // float
    constexpr uintptr_t MaxAcceleration          = 0x0258; // float
    constexpr uintptr_t BrakingFrictionFactor    = 0x0260; // float
    constexpr uintptr_t JumpZVelocity            = 0x0178; // float
    constexpr uintptr_t Velocity                 = 0x00D8; // FVector (double)

    // APlayerCameraManager
    constexpr uintptr_t CameraCachePrivate       = 0x1390; // FCameraCacheEntry
    constexpr uintptr_t POV                      = 0x13A0; // FMinimalViewInfo (Location, Rotation, FOV)
    constexpr uintptr_t DefaultFOV               = 0x02A4; // float
} // namespace Engine

// ----------------------------------------------------------------------------
// 3. ASoccerPlayer_C (Gameplay, Stamina, Kick, GK & Anti-Cheat Checks)
// ----------------------------------------------------------------------------
namespace ASoccerPlayer {
    // Hitbox Components (UBoxComponent* / UCapsuleComponent*)
    constexpr uintptr_t HeadingHitbox              = 0x06F0;
    constexpr uintptr_t BallCollisionHitbox        = 0x06F8;
    constexpr uintptr_t BicycleHitbox              = 0x0700;
    constexpr uintptr_t GkDivingHitbox             = 0x0708;
    constexpr uintptr_t GkStandingHitbox           = 0x0710;
    constexpr uintptr_t KickHitbox                 = 0x0718;

    // Camera & FOV Controls
    constexpr uintptr_t FirstPersonCamera          = 0x0748; // UCameraComponent*
    constexpr uintptr_t ThirdPersonCamera          = 0x0758; // UCameraComponent*
    constexpr uintptr_t ThirdPersonCameraDistance  = 0x0D18; // double
    constexpr uintptr_t ThirdPersonCameraHeight    = 0x0D20; // double
    constexpr uintptr_t FreeLookActive             = 0x0D01; // bool
    constexpr uintptr_t FreeLookYaw                = 0x0D08; // double
    constexpr uintptr_t FreeLookPitch              = 0x0D10; // double
    constexpr uintptr_t FreeLookLocked             = 0x1E10; // bool

    // Aim & Rotation
    constexpr uintptr_t AimHorizontal              = 0x0CB8; // double
    constexpr uintptr_t AimVertical                = 0x0CC0; // double
    constexpr uintptr_t HeadYaw                    = 0x0CC8; // double
    constexpr uintptr_t HeadPitch                  = 0x0CD0; // double

    // Sprint & Infinite Stamina
    constexpr uintptr_t SprintButtonPressed        = 0x0CF0; // bool
    constexpr uintptr_t Sprinting                  = 0x0CF1; // bool
    constexpr uintptr_t Stamina                    = 0x0CF8; // double (1.0 = Full)
    constexpr uintptr_t StaminaCooldown            = 0x0D00; // bool (false = No Exhaust)
    constexpr uintptr_t InTouchSlowdown            = 0x1DF8; // bool

    // Player Info
    constexpr uintptr_t PlayerName                 = 0x0D38; // FString
    constexpr uintptr_t Team                       = 0x0D48; // int32 (0 = Home, 1 = Away)
    constexpr uintptr_t Position                   = 0x0D4C; // int32

    // Shot / Kick Charge & Cooldown
    constexpr uintptr_t HoldingKickCharge          = 0x0D50; // bool
    constexpr uintptr_t HoldingKickChargeApplied   = 0x0D51; // bool
    constexpr uintptr_t HoldingKickChargeType      = 0x0D54; // int32
    constexpr uintptr_t HoldingKickChargePower     = 0x0D58; // double (0.0 -> 1.0)
    constexpr uintptr_t HoldingKickChargeVerticalInput   = 0x0D60; // double
    constexpr uintptr_t HoldingKickChargeHorizontalInput = 0x0D68; // double
    constexpr uintptr_t KickCoolDown               = 0x1B70; // bool (false = No Kick Delay)

    // Goalkeeper (GK) & Ball Pointers
    constexpr uintptr_t GkModeActive               = 0x1728; // bool
    constexpr uintptr_t GkInTeamPenaltyBox         = 0x1729; // bool
    constexpr uintptr_t GkPassBackRuleActive       = 0x172A; // bool
    constexpr uintptr_t GkDiveExpended             = 0x172D; // bool (false = Infinite Dive)
    constexpr uintptr_t GkPossessingBall           = 0x172E; // bool
    constexpr uintptr_t GkPossessedBall            = 0x1730; // ASoccerBall_C*
    constexpr uintptr_t ThrowInPossessingBall      = 0x1738; // bool
    constexpr uintptr_t ThrowInPossessedBall       = 0x1740; // ASoccerBall_C*
    constexpr uintptr_t PersonalBall               = 0x1748; // ASoccerBall_C*

    // Tackle & Offside
    constexpr uintptr_t SlideTackleActive          = 0x1754; // bool
    constexpr uintptr_t Offside                    = 0x1755; // bool
    constexpr uintptr_t OffsideLocation            = 0x1758; // FVector (double X, Y, Z)

    // Client-Side Anti-Cheat / Sanity Counters
    constexpr uintptr_t SpeedFailed                = 0x1C18; // int32
    constexpr uintptr_t PlayerWasJustMoved         = 0x1C1C; // bool
    constexpr uintptr_t TouchDecelFailed           = 0x1C20; // int32
    constexpr uintptr_t AccelerationFailed         = 0x1C24; // int32
    constexpr uintptr_t MaxAccelerationFailed      = 0x1C28; // int32
    constexpr uintptr_t TimelinesFailed            = 0x1C2C; // int32
    constexpr uintptr_t CameraFailed               = 0x1C30; // int32
    constexpr uintptr_t CallbacksFailed            = 0x1C34; // int32
} // namespace ASoccerPlayer

} // namespace PSO_Offsets