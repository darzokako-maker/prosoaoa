#include "pso/bypass/BypassConfig.hpp"
#include "pso/bypass/Injector.hpp"
#include "pso/core/Memory.hpp"
#include "pso/core/Process.hpp"
#include "pso/sdk/BasicTypes.hpp"
#include "pso/sdk/GameClasses.hpp"
#include "pso/sdk/PSOOffsets.hpp"

#include <Windows.h>
#include <atomic>
#include <chrono>
#include <iomanip>
#include <iostream>
#include <mutex>
#include <string>
#include <thread>

// ============================================================================
// Offset resolver: try hardcoded offset first, validate by reading the
// pointer at that address, fall back to AOB pattern scan.
// ============================================================================

static bool IsValidRemotePtr(uintptr_t ptr) {
  return ptr != 0 && ptr >= 0x10000 && ptr < 0x00007FFFFFFFFFFFULL;
}

// Resolve GObjects: hardcoded offset first, pattern scan fallback.
static uintptr_t ResolveGObjects(const Memory &mem, uintptr_t baseAddress,
                                 uintptr_t moduleSize) {
  uintptr_t hardcoded = baseAddress + Offsets::GObjects;
  uintptr_t chunksPtr = mem.read<uintptr_t>(hardcoded);
  if (IsValidRemotePtr(chunksPtr)) {
    return hardcoded;
  }

  std::cout << "[!] Hardcoded GObjects offset stale. Pattern scanning...\n";
  uintptr_t scanned = mem.FindPattern(baseAddress, moduleSize,
                                      Offsets::Sig_GObjects);
  if (scanned != 0) {
    std::cout << "[+] GObjects found via pattern scan at: 0x" << std::hex
              << scanned << std::dec << "\n";
  }
  return scanned;
}

// ============================================================================
// Shared-config IPC with injected bypass DLL
// ============================================================================
static HANDLE g_bypassConfigMap = nullptr;
static BypassSharedConfig* g_bypassSharedConfig = nullptr;

static bool InitBypassSharedConfig() {
  g_bypassConfigMap = OpenFileMappingW(FILE_MAP_ALL_ACCESS, FALSE,
                                       BYPASS_CONFIG_SECTION_NAME);
  if (!g_bypassConfigMap) {
    std::cout << "[!] Could not open bypass shared config (DLL not injected?).\n";
    return false;
  }

  g_bypassSharedConfig = reinterpret_cast<BypassSharedConfig *>(
      MapViewOfFile(g_bypassConfigMap, FILE_MAP_ALL_ACCESS, 0, 0,
                    sizeof(BypassSharedConfig)));
  if (!g_bypassSharedConfig) {
    std::cout << "[!] MapViewOfFile failed: " << GetLastError() << "\n";
    CloseHandle(g_bypassConfigMap);
    g_bypassConfigMap = nullptr;
    return false;
  }
  std::cout << "[+] Bypass shared-config IPC connected.\n";
  return true;
}

static void CloseBypassSharedConfig() {
  if (g_bypassSharedConfig) {
    UnmapViewOfFile(g_bypassSharedConfig);
    g_bypassSharedConfig = nullptr;
  }
  if (g_bypassConfigMap) {
    CloseHandle(g_bypassConfigMap);
    g_bypassConfigMap = nullptr;
  }
}

// ============================================================================
// Feature state (local UI state; server-side features live in shared config)
// ============================================================================
struct FeatureState {
  std::atomic<bool> staminaEnabled{false};
  std::atomic<double> staminaValue{100.0};

  std::atomic<bool> kickPowerEnabled{false};
  std::atomic<double> kickPowerValue{1.0};

  std::atomic<bool> cameraDistEnabled{false};
  std::atomic<double> cameraDistValue{500.0};

  std::atomic<bool> cameraHeightEnabled{false};
  std::atomic<double> cameraHeightValue{120.0};

  std::atomic<bool> antiCheatResetEnabled{false};

  std::atomic<bool> dllInjected{false};

  std::atomic<bool> running{true};
};

// ============================================================================
// Player values read from game
// ============================================================================
struct PlayerValues {
  std::string playerName;
  int32_t team = -1;
  int32_t position = -1;
  double stamina = 0.0;
  double kickChargePower = 0.0;
  double cameraDistance = 0.0;
  double cameraHeight = 0.0;
  bool gkMode = false;

  // Anti-cheat counters
  int32_t speedFailed = 0;
  int32_t accelFailed = 0;
  int32_t maxAccelFailed = 0;
  int32_t timelinesFailed = 0;
  int32_t cameraFailed = 0;
  int32_t callbacksFailed = 0;
};

// ============================================================================
// Find ASoccerPlayer_C actor by scanning GObjects
// ============================================================================
uintptr_t findPlayerActor(const Memory &mem, uintptr_t baseAddress,
                          uintptr_t moduleSize) {
  // Resolve GObjects (hardcoded first, pattern scan fallback)
  uintptr_t gobjectsAddr = ResolveGObjects(mem, baseAddress, moduleSize);
  if (gobjectsAddr == 0) {
    std::cout << "[!] Could not resolve GObjects.\n";
    return 0;
  }

  // Read chunked array pointers
  uintptr_t chunksPtr = mem.read<uintptr_t>(gobjectsAddr + GObjects_Layout::Objects);
  int32_t numElements =
      mem.read<int32_t>(gobjectsAddr + GObjects_Layout::NumElements);
  int32_t numChunks =
      mem.read<int32_t>(gobjectsAddr + GObjects_Layout::NumChunks);

  if (chunksPtr == 0 || numElements <= 0 || numChunks <= 0) {
    return 0;
  }

  // Cap for safety
  if (numElements > 2000000)
    numElements = 2000000;
  if (numChunks > 200)
    numChunks = 200;

  for (int32_t i = 0; i < numElements; i++) {
    int32_t chunkIdx = i / GObjects_Layout::ElementsPerChunk;
    int32_t inChunkIdx = i % GObjects_Layout::ElementsPerChunk;

    if (chunkIdx >= numChunks)
      break;

    // Read chunk pointer
    uintptr_t chunkPtr =
        mem.read<uintptr_t>(chunksPtr + chunkIdx * sizeof(uintptr_t));
    if (chunkPtr == 0)
      continue;

    // Read UObject* from FUObjectItem
    uintptr_t objectPtr =
        mem.read<uintptr_t>(chunkPtr + inChunkIdx * GObjects_Layout::ItemSize);
    if (objectPtr == 0)
      continue;

    // Read the UClass* for this object
    uintptr_t classPtr = mem.read<uintptr_t>(objectPtr + UObject_Off::Class);
    if (classPtr == 0)
      continue;

    // Read PropertiesSize of the class
    int32_t propSize =
        mem.read<int32_t>(classPtr + UStruct_Off::PropertiesSize);

    // Identify ASoccerPlayer_C / POV_Character_C by PropertiesSize == 0x1EC0
    if (propSize == POV_Character::ClassSize) {
      // Additional validation: check that this is not a CDO (default object)
      uintptr_t nameDataPtr =
          mem.read<uintptr_t>(objectPtr + POV_Character::playerName);
      int32_t nameCount =
          mem.read<int32_t>(objectPtr + POV_Character::playerName + 8);

      // If it has a valid name, it's likely a real actor instance
      if (nameDataPtr != 0 && nameCount > 0 && nameCount < 200) {
        return objectPtr;
      }
    }
  }

  return 0;
}

// ============================================================================
// Read current player values
// ============================================================================
PlayerValues readPlayerValues(const Memory &mem, uintptr_t playerActor) {
  PlayerValues vals;

  // Player name
  std::wstring wname = mem.readFString(playerActor + POV_Character::playerName);
  vals.playerName = Memory::wideToNarrow(wname);

  // Team / Position
  vals.team = mem.read<int32_t>(playerActor + POV_Character::Team);
  vals.position = mem.read<int32_t>(playerActor + POV_Character::Position);

  // Stamina
  vals.stamina = mem.read<double>(playerActor + POV_Character::Stamina);

  // Kick power
  vals.kickChargePower =
      mem.read<double>(playerActor + POV_Character::HoldingKickChargePower);

  // Camera distance/height
  vals.cameraDistance = mem.read<double>(
      playerActor + POV_Character::ThreerdPersonCameraDistance);
  vals.cameraHeight =
      mem.read<double>(playerActor + POV_Character::ThreerdPersonCameraHeight);

  // GK mode
  vals.gkMode = mem.read<bool>(playerActor + POV_Character::GkModeActive);

  // Anti-cheat counters
  vals.speedFailed =
      mem.read<int32_t>(playerActor + POV_Character::SpeedFailed);
  vals.accelFailed =
      mem.read<int32_t>(playerActor + POV_Character::AccelerationFailed);
  vals.maxAccelFailed =
      mem.read<int32_t>(playerActor + POV_Character::MaxAccelerationFailed);
  vals.timelinesFailed =
      mem.read<int32_t>(playerActor + POV_Character::TimelinesFailed);
  vals.cameraFailed =
      mem.read<int32_t>(playerActor + POV_Character::CameraFailed);
  vals.callbacksFailed =
      mem.read<int32_t>(playerActor + POV_Character::CallbacksFailed);

  return vals;
}

// ============================================================================
// Validate that the actor pointer is still valid
// ============================================================================
bool validateActor(const Memory &mem, uintptr_t playerActor) {
  if (playerActor == 0)
    return false;

  uintptr_t classPtr = mem.read<uintptr_t>(playerActor + UObject_Off::Class);
  if (classPtr == 0)
    return false;

  int32_t propSize = mem.read<int32_t>(classPtr + UStruct_Off::PropertiesSize);
  return propSize == POV_Character::ClassSize;
}

// ============================================================================
// Writer thread — continuously writes enabled features
// ============================================================================
void writerThread(const Memory &mem, std::atomic<uintptr_t> &playerActorAddr,
                  FeatureState &state) {
  using namespace std::chrono;

  while (state.running.load()) {
    uintptr_t actor = playerActorAddr.load();

    if (actor == 0 || !validateActor(mem, actor)) {
      std::this_thread::sleep_for(milliseconds(500));
      continue;
    }

    // Stamina
    if (state.staminaEnabled.load()) {
      double val = state.staminaValue.load();
      mem.write<double>(actor + POV_Character::Stamina, val);
      mem.write<bool>(actor + POV_Character::StaminaCooldown, false);
    }

    // Kick power
    if (state.kickPowerEnabled.load()) {
      double val = state.kickPowerValue.load();
      mem.write<double>(actor + POV_Character::HoldingKickChargePower, val);
    }

    // Camera distance (write to the variable directly)
    if (state.cameraDistEnabled.load()) {
      double val = state.cameraDistValue.load();
      mem.write<double>(actor + POV_Character::ThreerdPersonCameraDistance,
                        val);
    }

    // Camera height
    if (state.cameraHeightEnabled.load()) {
      double val = state.cameraHeightValue.load();
      mem.write<double>(actor + POV_Character::ThreerdPersonCameraHeight, val);
    }

    // Anti-cheat counter reset
    if (state.antiCheatResetEnabled.load()) {
      int32_t zero = 0;
      mem.write<int32_t>(actor + POV_Character::SpeedFailed, zero);
      mem.write<int32_t>(actor + POV_Character::TouchDecelFailed, zero);
      mem.write<int32_t>(actor + POV_Character::AccelerationFailed, zero);
      mem.write<int32_t>(actor + POV_Character::MaxAccelerationFailed, zero);
      mem.write<int32_t>(actor + POV_Character::TimelinesFailed, zero);
      mem.write<int32_t>(actor + POV_Character::CameraFailed, zero);
      mem.write<int32_t>(actor + POV_Character::CallbacksFailed, zero);
    }

    // ~120 fps write rate
    std::this_thread::sleep_for(milliseconds(8));
  }
}

// ============================================================================
// Display helpers
// ============================================================================
void clearScreen() {
  HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
  COORD topLeft = {0, 0};
  CONSOLE_SCREEN_BUFFER_INFO csbi;
  DWORD written;

  GetConsoleScreenBufferInfo(hConsole, &csbi);
  DWORD size = csbi.dwSize.X * csbi.dwSize.Y;
  FillConsoleOutputCharacterW(hConsole, L' ', size, topLeft, &written);
  FillConsoleOutputAttribute(hConsole, csbi.wAttributes, size, topLeft,
                             &written);
  SetConsoleCursorPosition(hConsole, topLeft);
}

std::string onOff(bool enabled) { return enabled ? "[ON] " : "[OFF]"; }

void printMenu(const FeatureState &state, const PlayerValues &vals) {
  clearScreen();

  std::cout << "============================================\n";
  std::cout << "   PSO Analyzer - Pro Soccer Online Tool\n";
  std::cout << "============================================\n\n";

  std::cout << "  Player: "
            << (vals.playerName.empty() ? "???" : vals.playerName) << "\n";
  std::cout << "  Team: " << vals.team << "  |  Position: " << vals.position;
  if (vals.gkMode)
    std::cout << " (GK)";
  std::cout << "\n\n";

  std::cout << "--- Current Values ---\n";
  std::cout << "  Stamina:       " << std::fixed << std::setprecision(1)
            << vals.stamina << "\n";
  std::cout << "  Kick Power:    " << std::fixed << std::setprecision(2)
            << vals.kickChargePower << "\n";
  std::cout << "  Cam Distance:  " << std::fixed << std::setprecision(1)
            << vals.cameraDistance << "\n";
  std::cout << "  Cam Height:    " << std::fixed << std::setprecision(1)
            << vals.cameraHeight << "\n\n";

  std::cout << "--- AC Counters ---\n";
  std::cout << "  Speed:" << vals.speedFailed << "  Accel:" << vals.accelFailed
            << "  MaxAccel:" << vals.maxAccelFailed
            << "  TL:" << vals.timelinesFailed << "  Cam:" << vals.cameraFailed
            << "  CB:" << vals.callbacksFailed << "\n\n";

  std::cout << "--- Features ---\n";
  std::cout << "  [1] " << onOff(state.staminaEnabled.load()) << " Stamina ("
            << state.staminaValue.load() << ")\n";
  std::cout << "  [2] " << onOff(state.kickPowerEnabled.load())
            << " Kick Power (" << state.kickPowerValue.load() << ")\n";
  std::cout << "  [3] " << onOff(state.cameraDistEnabled.load())
            << " Camera Distance (" << state.cameraDistValue.load() << ")\n";
  std::cout << "  [4] " << onOff(state.cameraHeightEnabled.load())
            << " Camera Height (" << state.cameraHeightValue.load() << ")\n";
  std::cout << "  [5] " << onOff(state.antiCheatResetEnabled.load())
            << " AC Counter Reset\n\n";

  std::cout << "  [6] Set Stamina Value\n";
  std::cout << "  [7] Set Kick Power Value\n";
  std::cout << "  [8] Set Camera Distance Value\n";
  std::cout << "  [9] Set Camera Height Value\n\n";

  std::cout << "--- Server-Side Bypass ---\n";
  std::cout << "  [I] " << (state.dllInjected.load() ? "[INJECTED]" : "[READY]")
            << " Inject Bypass DLL\n\n";

  std::cout << "  [R] Rescan for player actor\n";
  std::cout << "  [0] Exit\n\n";

  std::cout << "  > ";
}

// ============================================================================
// Main
// ============================================================================
int main() {
  SetConsoleTitleW(L"PSO Analyzer");

  // Enable virtual terminal processing for colors (optional)
  HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
  DWORD dwMode = 0;
  GetConsoleMode(hOut, &dwMode);
  SetConsoleMode(hOut, dwMode | ENABLE_VIRTUAL_TERMINAL_PROCESSING);

  std::cout << "============================================\n";
  std::cout << "   PSO Analyzer - Pro Soccer Online Tool\n";
  std::cout << "============================================\n\n";

  // Attach to process
  Process proc;
  std::cout << "[*] Searching for ProSoccerOnline-Win64-Shipping.exe...\n";

  int attempts = 0;
  while (!proc.attach(L"ProSoccerOnline-Win64-Shipping.exe")) {
    if (++attempts > 30) {
      std::cout << "[!] Could not find game process after 30 attempts.\n";
      std::cout << "    Make sure the game is running.\n";
      std::cout << "    Press Enter to retry or Ctrl+C to exit...\n";
      std::cin.get();
      attempts = 0;
    }
    std::this_thread::sleep_for(std::chrono::seconds(1));
    if (attempts % 5 == 0 && attempts > 0) {
      std::cout << "[*] Still searching... (" << attempts << "s)\n";
    }
  }

  std::cout << "[+] Attached to process! PID: " << proc.pid() << "\n";
  std::cout << "[+] Base Address: 0x" << std::hex << proc.baseAddress()
            << std::dec << "\n";
  std::cout << "[+] Module Size: 0x" << std::hex << proc.moduleSize()
            << std::dec << "\n\n";

  Memory mem(proc.handle());

  // Find player actor
  std::cout << "[*] Scanning for player actor...\n";
  std::atomic<uintptr_t> playerActorAddr{0};

  uintptr_t actor = findPlayerActor(mem, proc.baseAddress(), proc.moduleSize());
  if (actor != 0) {
    playerActorAddr.store(actor);
    std::cout << "[+] Found player actor at: 0x" << std::hex << actor
              << std::dec << "\n";

    auto vals = readPlayerValues(mem, actor);
    std::cout << "[+] Player: " << vals.playerName << " | Team: " << vals.team
              << "\n";
  } else {
    std::cout << "[!] Player actor not found. Join a match first, then press "
                 "[R] to rescan.\n";
  }

  std::cout << "\nPress Enter to continue...";
  std::cin.get();

  // Start feature state and writer thread
  FeatureState state;
  std::thread writer(writerThread, std::cref(mem), std::ref(playerActorAddr),
                     std::ref(state));

  // Main menu loop
  bool running = true;
  while (running) {
    // Read live values
    PlayerValues vals;
    uintptr_t currentActor = playerActorAddr.load();
    if (currentActor != 0 && validateActor(mem, currentActor)) {
      vals = readPlayerValues(mem, currentActor);
    }

    printMenu(state, vals);

    std::string input;
    std::getline(std::cin, input);

    if (input.empty())
      continue;

    char choice = input[0];

    switch (choice) {
    case '1': {
      bool enabled = !state.staminaEnabled.load();
      state.staminaEnabled.store(enabled);
      if (g_bypassSharedConfig)
        g_bypassSharedConfig->staminaBypass = enabled;
      break;
    }

    case '2': {
      bool enabled = !state.kickPowerEnabled.load();
      state.kickPowerEnabled.store(enabled);
      if (g_bypassSharedConfig)
        g_bypassSharedConfig->kickPowerBypass = enabled;
      break;
    }

    case '3':
      state.cameraDistEnabled.store(!state.cameraDistEnabled.load());
      break;

    case '4':
      state.cameraHeightEnabled.store(!state.cameraHeightEnabled.load());
      break;

    case '5': {
      bool enabled = !state.antiCheatResetEnabled.load();
      state.antiCheatResetEnabled.store(enabled);
      if (g_bypassSharedConfig)
        g_bypassSharedConfig->acResetBypass = enabled;
      break;
    }

    case '6': {
      std::cout << "  Enter stamina value (0-100): ";
      std::string valStr;
      std::getline(std::cin, valStr);
      try {
        double v = std::stod(valStr);
        state.staminaValue.store(v);
      } catch (...) {
      }
      break;
    }

    case '7': {
      std::cout << "  Enter kick power value (default 1.0): ";
      std::string valStr;
      std::getline(std::cin, valStr);
      try {
        double v = std::stod(valStr);
        state.kickPowerValue.store(v);
      } catch (...) {
      }
      break;
    }

    case '8': {
      std::cout << "  Enter camera distance value: ";
      std::string valStr;
      std::getline(std::cin, valStr);
      try {
        double v = std::stod(valStr);
        state.cameraDistValue.store(v);
      } catch (...) {
      }
      break;
    }

    case '9': {
      std::cout << "  Enter camera height value: ";
      std::string valStr;
      std::getline(std::cin, valStr);
      try {
        double v = std::stod(valStr);
        state.cameraHeightValue.store(v);
      } catch (...) {
      }
      break;
    }

    case 'i':
    case 'I': {
      if (state.dllInjected.load()) {
        std::cout << "  [!] Bypass DLL already injected!\n";
      } else {
        std::cout << "  [*] Injecting Bypass DLL...\n";
        std::wstring dllPath = DllInjector::GetDllPath();
        std::wcout << L"  [*] DLL Path: " << dllPath << L"\n";

        if (DllInjector::Inject(proc.pid(), dllPath)) {
          state.dllInjected.store(true);
          InitBypassSharedConfig();
          std::cout << "  [+] Bypass DLL injected successfully!\n";
          std::cout << "  [+] A console window should appear in the game.\n";
          std::cout << "  [+] Use that console to control bypass features.\n";
        } else {
          std::cout << "  [!] DLL injection failed!\n";
          std::cout << "  [!] Make sure you run as Administrator.\n";
        }
      }
      std::cout << "  Press Enter...";
      std::string dummy;
      std::getline(std::cin, dummy);
      break;
    }

    case 'r':
    case 'R': {
      std::cout << "  [*] Rescanning for player actor...\n";
      uintptr_t newActor =
          findPlayerActor(mem, proc.baseAddress(), proc.moduleSize());
      if (newActor != 0) {
        playerActorAddr.store(newActor);
        auto v = readPlayerValues(mem, newActor);
        std::cout << "  [+] Found: " << v.playerName << " at 0x" << std::hex
                  << newActor << std::dec << "\n";
      } else {
        std::cout << "  [!] Player actor not found.\n";
      }
      std::cout << "  Press Enter...";
      std::string dummy;
      std::getline(std::cin, dummy);
      break;
    }

    case '0':
      running = false;
      break;

    default:
      break;
    }
  }

  // Cleanup
  state.running.store(false);
  if (writer.joinable()) {
    writer.join();
  }
  CloseBypassSharedConfig();

  std::cout << "\n[*] Exiting. Goodbye!\n";
  return 0;
}