#include "pso/core/Process.hpp"
#include <iostream>

Process::~Process() { detach(); }

bool Process::attach(const std::wstring &processName) {
  m_pid = findProcessId(processName);
  if (m_pid == 0) {
    return false;
  }

  m_handle = OpenProcess(PROCESS_ALL_ACCESS, FALSE, m_pid);
  if (m_handle == nullptr) {
    m_pid = 0;
    return false;
  }

  m_baseAddress = getModuleBase();
  if (m_baseAddress == 0) {
    CloseHandle(m_handle);
    m_handle = nullptr;
    m_pid = 0;
    return false;
  }

  m_moduleSize = getModuleSize();
  if (m_moduleSize == 0) {
    CloseHandle(m_handle);
    m_handle = nullptr;
    m_pid = 0;
    m_baseAddress = 0;
    return false;
  }

  return true;
}

void Process::detach() {
  if (m_handle) {
    CloseHandle(m_handle);
    m_handle = nullptr;
  }
  m_pid = 0;
  m_baseAddress = 0;
  m_moduleSize = 0;
}

DWORD Process::findProcessId(const std::wstring &processName) {
  HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
  if (snapshot == INVALID_HANDLE_VALUE)
    return 0;

  PROCESSENTRY32W entry{};
  entry.dwSize = sizeof(entry);

  DWORD pid = 0;
  if (Process32FirstW(snapshot, &entry)) {
    do {
      if (processName == entry.szExeFile) {
        pid = entry.th32ProcessID;
        break;
      }
    } while (Process32NextW(snapshot, &entry));
  }

  CloseHandle(snapshot);
  return pid;
}

uintptr_t Process::getModuleBase() {
  if (!m_handle)
    return 0;

  HMODULE modules[1];
  DWORD needed = 0;

  if (EnumProcessModulesEx(m_handle, modules, sizeof(modules), &needed,
                           LIST_MODULES_64BIT)) {
    MODULEINFO info{};
    if (GetModuleInformation(m_handle, modules[0], &info, sizeof(info))) {
      return reinterpret_cast<uintptr_t>(info.lpBaseOfDll);
    }
  }

  return 0;
}

uintptr_t Process::getModuleSize() {
  if (!m_handle || m_baseAddress == 0)
    return 0;

  IMAGE_DOS_HEADER dosHeader{};
  if (!ReadProcessMemory(m_handle, reinterpret_cast<LPCVOID>(m_baseAddress),
                         &dosHeader, sizeof(dosHeader), nullptr)) {
    return 0;
  }

  if (dosHeader.e_magic != IMAGE_DOS_SIGNATURE)
    return 0;

  IMAGE_NT_HEADERS64 ntHeaders{};
  if (!ReadProcessMemory(m_handle,
                         reinterpret_cast<LPCVOID>(
                             m_baseAddress + dosHeader.e_lfanew),
                         &ntHeaders, sizeof(ntHeaders), nullptr)) {
    return 0;
  }

  if (ntHeaders.Signature != IMAGE_NT_SIGNATURE)
    return 0;

  return ntHeaders.OptionalHeader.SizeOfImage;
}