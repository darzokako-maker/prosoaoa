// ============================================================================
// PSO Analyzer — Server-Side Bypass DLL v8
// Dual Hook: VMT Shadowing (primary) + Inline Detour (fallback)
// Shared-config IPC, thread stealth, AC jitter, hook health-check.
// ============================================================================
#define WIN32_LEAN_AND_MEAN
#include <Windows.h>
#include <atomic>
#include <cstdint>
#include <cstdarg>
#include <cstring>
#include <cstdlib>
#include <string>
#include <vector>
#include <mutex>

#include "pso/bypass/BypassConfig.hpp"

static uintptr_t g_moduleBase = 0;
static uintptr_t g_moduleSize = 0;
static HMODULE g_dllModule = nullptr;
static std::atomic<bool> g_running{true};
static std::atomic<uintptr_t> g_playerActor{0};
static std::mutex g_logMutex;

// ----------------------------------------------------------------------------
// Shared-config IPC (external tool can update bypass settings at runtime)
// ----------------------------------------------------------------------------
static HANDLE g_configMap = nullptr;
static BypassSharedConfig* g_sharedConfig = nullptr;

// ----------------------------------------------------------------------------
// Hook state
// ----------------------------------------------------------------------------
typedef void (*ProcessEvent_t)(void *, void *, void *);
static ProcessEvent_t g_originalProcessEvent = nullptr;

// Cached UFunction pointers
static void *g_func_KickSoccerBall = nullptr;
static void *g_func_HeaderSoccerBall = nullptr;
static void *g_func_SetStaminaClient = nullptr;
static void *g_func_SetStaminaClientReliable = nullptr;
static void *g_func_SetSpeedAccelClient = nullptr;
static void *g_func_ReduceStamina = nullptr;
static void *g_func_StartKickChargeHold = nullptr;

// VMT shadowing
static void **g_fakeVTable = nullptr;
static void **g_originalVTable = nullptr;
static constexpr int VTABLE_SIZE = 512;

// Inline detour
static uint8_t g_originalBytes[14] = {0};
static uint8_t *g_trampoline = nullptr;
static uintptr_t g_processEventAddr = 0;
static bool g_usingVMTShadow = false;

// ----------------------------------------------------------------------------
// Logging (OutputDebugString = stealthy, no console spam)
// ----------------------------------------------------------------------------
static void Log(const char *fmt, ...) {
  std::lock_guard<std::mutex> lock(g_logMutex);
  char buf[512];
  va_list args;
  va_start(args, fmt);
  vsnprintf(buf, sizeof(buf), fmt, args);
  va_end(args);
  OutputDebugStringA("[PSO] ");
  OutputDebugStringA(buf);
  OutputDebugStringA("\n");
}

// ----------------------------------------------------------------------------
// Pointer validation
// ----------------------------------------------------------------------------
static bool IsValidPtr(uintptr_t ptr) {
  return ptr != 0 && ptr >= 0x10000 && ptr < 0x00007FFFFFFFFFFFULL;
}

// ----------------------------------------------------------------------------
// Local PE helpers (DLL runs inside the target process)
// ----------------------------------------------------------------------------
static uintptr_t GetLocalModuleSize(uintptr_t baseAddress) {
  PIMAGE_DOS_HEADER dosHeader = reinterpret_cast<PIMAGE_DOS_HEADER>(baseAddress);
  if (dosHeader->e_magic != IMAGE_DOS_SIGNATURE)
    return 0;
  PIMAGE_NT_HEADERS ntHeader =
      reinterpret_cast<PIMAGE_NT_HEADERS>(baseAddress + dosHeader->e_lfanew);
  if (ntHeader->Signature != IMAGE_NT_SIGNATURE)
    return 0;
  return ntHeader->OptionalHeader.SizeOfImage;
}

// ----------------------------------------------------------------------------
// Pattern scanner (local, in-process)
// ----------------------------------------------------------------------------
static uintptr_t FindPattern(uintptr_t startAddress, uintptr_t size,
                             const char *signature) {
  auto patternToByte = [](const char *pattern) {
    std::vector<int> bytes;
    const char *start = pattern;
    const char *end = pattern + std::strlen(pattern);
    for (const char *current = start; current < end; ++current) {
      if (*current == '?') {
        ++current;
        if (current < end && *current == '?')
          ++current;
        bytes.push_back(-1);
      } else {
        bytes.push_back(static_cast<int>(std::strtoul(
            current, const_cast<char **>(&current), 16)));
      }
    }
    return bytes;
  };

  auto patternBytes = patternToByte(signature);
  auto patternSize = patternBytes.size();
  if (patternSize == 0)
    return 0;

  auto d = reinterpret_cast<const uint8_t *>(startAddress);
  for (uintptr_t i = 0; i + patternSize <= size; ++i) {
    bool found = true;
    for (size_t j = 0; j < patternSize; ++j) {
      if (d[i + j] != static_cast<uint8_t>(patternBytes[j]) &&
          patternBytes[j] != -1) {
        found = false;
        break;
      }
    }
    if (found)
      return startAddress + i;
  }
  return 0;
}

// ----------------------------------------------------------------------------
// Offset resolver: hardcoded first, pattern-scan fallback
// ----------------------------------------------------------------------------
static uintptr_t ResolveGObjects() {
  uintptr_t hardcoded = g_moduleBase + BypassOffsets::GObjects;
  uintptr_t chunksPtr = *reinterpret_cast<uintptr_t *>(hardcoded);
  if (IsValidPtr(chunksPtr)) {
    Log("GObjects resolved via hardcoded offset: 0x%llX", hardcoded);
    return hardcoded;
  }

  Log("Hardcoded GObjects offset stale. Pattern scanning...");
  if (g_moduleSize == 0)
    g_moduleSize = GetLocalModuleSize(g_moduleBase);
  uintptr_t scanned = FindPattern(g_moduleBase, g_moduleSize,
                                  BypassOffsets::Sig_GObjects);
  if (scanned != 0)
    Log("GObjects found via pattern scan: 0x%llX", scanned);
  return scanned;
}

static uintptr_t ResolveGNames() {
  uintptr_t hardcoded = g_moduleBase + BypassOffsets::GNames;
  if (IsValidPtr(hardcoded)) {
    uintptr_t firstDeref = *reinterpret_cast<uintptr_t *>(hardcoded);
    if (firstDeref == 0 || IsValidPtr(firstDeref)) {
      Log("GNames resolved via hardcoded offset: 0x%llX", hardcoded);
      return hardcoded;
    }
  }

  Log("Hardcoded GNames offset stale. Pattern scanning...");
  if (g_moduleSize == 0)
    g_moduleSize = GetLocalModuleSize(g_moduleBase);
  uintptr_t scanned = FindPattern(g_moduleBase, g_moduleSize,
                                  BypassOffsets::Sig_GNames);
  if (scanned != 0)
    Log("GNames found via pattern scan: 0x%llX", scanned);
  return scanned;
}

// ----------------------------------------------------------------------------
// Shared-config IPC
// ----------------------------------------------------------------------------
static bool InitSharedConfig() {
  g_configMap = CreateFileMappingW(INVALID_HANDLE_VALUE, nullptr,
                                   PAGE_READWRITE, 0,
                                   sizeof(BypassSharedConfig),
                                   BYPASS_CONFIG_SECTION_NAME);
  if (!g_configMap) {
    Log("CreateFileMapping failed: %lu", GetLastError());
    return false;
  }

  g_sharedConfig = reinterpret_cast<BypassSharedConfig *>(
      MapViewOfFile(g_configMap, FILE_MAP_ALL_ACCESS, 0, 0,
                    sizeof(BypassSharedConfig)));
  if (!g_sharedConfig) {
    Log("MapViewOfFile failed: %lu", GetLastError());
    CloseHandle(g_configMap);
    g_configMap = nullptr;
    return false;
  }

  // Initialize if magic is invalid
  if (g_sharedConfig->magic != BYPASS_CONFIG_MAGIC) {
    *g_sharedConfig = BypassSharedConfig{};
  }
  Log("Shared config IPC initialized.");
  return true;
}

static void SyncConfigFromShared(BypassSharedConfig &local) {
  if (!g_sharedConfig)
    return;
  local.staminaBypass = g_sharedConfig->staminaBypass;
  local.kickPowerBypass = g_sharedConfig->kickPowerBypass;
  local.speedBypass = g_sharedConfig->speedBypass;
  local.acResetBypass = g_sharedConfig->acResetBypass;
  local.blockReduceStamina = g_sharedConfig->blockReduceStamina;
  local.staminaValue = g_sharedConfig->staminaValue;
  local.kickPowerMultiplier = g_sharedConfig->kickPowerMultiplier;
  local.speedMultiplier = g_sharedConfig->speedMultiplier;
  local.accelerationMultiplier = g_sharedConfig->accelerationMultiplier;
  local.maxSafeSpeed = g_sharedConfig->maxSafeSpeed;
  local.maxSafeAcceleration = g_sharedConfig->maxSafeAcceleration;
  local.acCounterJitterMax = g_sharedConfig->acCounterJitterMax;
}

// ----------------------------------------------------------------------------
// Thread stealth: hide from debugger
// ----------------------------------------------------------------------------
static void HideThreadFromDebugger(HANDLE hThread) {
  HMODULE hNtdll = GetModuleHandleW(L"ntdll.dll");
  if (!hNtdll)
    return;
  typedef NTSTATUS(NTAPI * NtSetInformationThread_t)(
      HANDLE, UINT, PVOID, ULONG);
  auto pNtSetInformationThread =
      reinterpret_cast<NtSetInformationThread_t>(
          GetProcAddress(hNtdll, "NtSetInformationThread"));
  if (pNtSetInformationThread)
    pNtSetInformationThread(hThread, 0x11, nullptr, 0); // ThreadHideFromDebugger
}

// ----------------------------------------------------------------------------
// Simple LCG for AC-counter jitter
// ----------------------------------------------------------------------------
static uint32_t g_lcgState = 0xDEADBEEF;
static int32_t JitteredCounter(int32_t maxJitter) {
  if (maxJitter <= 0)
    return 0;
  g_lcgState = g_lcgState * 1664525u + 1013904223u;
  return static_cast<int32_t>(g_lcgState % static_cast<uint32_t>(maxJitter + 1));
}

// ----------------------------------------------------------------------------
// FName resolution
// ----------------------------------------------------------------------------
static uint8_t **g_FNameBlocks = nullptr;

static bool TestGNamesCandidate(uintptr_t namePoolBase, const char *source) {
  if (!IsValidPtr(namePoolBase))
    return false;

  uintptr_t basesToTest[2] = {namePoolBase, 0};
  if (IsValidPtr(*reinterpret_cast<uintptr_t *>(namePoolBase)))
    basesToTest[1] = *reinterpret_cast<uintptr_t *>(namePoolBase);

  for (int b = 0; b < 2; b++) {
    uintptr_t base = basesToTest[b];
    if (!base)
      continue;

    for (int i = 0; i <= 0x40; i += 8) {
      uint8_t **possibleBlocks = reinterpret_cast<uint8_t **>(base + i);
      if (IsValidPtr(reinterpret_cast<uintptr_t>(possibleBlocks)) &&
          IsValidPtr(reinterpret_cast<uintptr_t>(possibleBlocks[0]))) {

        uint8_t *entryPtr = possibleBlocks[0];
        uint16_t header = *reinterpret_cast<uint16_t *>(entryPtr);
        bool isWide = (header & 1) != 0;
        int32_t len = header >> 6;

        if (!isWide && len == 4) {
          std::string firstStr(reinterpret_cast<const char *>(entryPtr + 2),
                               len);
          if (firstStr == "None") {
            g_FNameBlocks = possibleBlocks;
            Log("DEBUG: %s produced FName Blocks at offset +0x%X", source, i);
            return true;
          }
        }
      }
    }
  }
  return false;
}

static bool DiscoverFNameBlocks() {
  uintptr_t gNamesAddr = ResolveGNames();
  if (!IsValidPtr(gNamesAddr)) {
    Log("ERROR: GNames address is invalid.");
    return false;
  }
  if (g_moduleSize == 0)
    g_moduleSize = GetLocalModuleSize(g_moduleBase);

  const char *sigs[] = {
      "4C 8D 05 ? ? ? ? EB ? 48 8D 0D ? ? ? ? E8",
      "48 8D 0D ? ? ? ? E8 ? ? ? ? C6 05 ? ? ? ? 01",
      "48 8D 05 ? ? ? ? EB ? 48 8D 0D ? ? ? ? E8",
      "4C 8D 0D ? ? ? ? 4C 8B C2 4C 8D 05"};

  for (int i = 0; i < 4; i++) {
    uintptr_t match = FindPattern(g_moduleBase, g_moduleSize, sigs[i]);
    if (match) {
      int32_t relativeOffset = *reinterpret_cast<int32_t *>(match + 3);
      uintptr_t candidate = match + 7 + relativeOffset;
      Log("DEBUG: Testing Signature %d candidate: 0x%llX", i, candidate);
      if (TestGNamesCandidate(candidate, "Pattern Scan"))
        return true;
    }
  }

  if (TestGNamesCandidate(gNamesAddr, "Hardcoded GNames"))
    return true;

  Log("ERROR: Could not discover FName Blocks array!");
  return false;
}

static std::string ResolveFName(int32_t compIdx, bool debug = false) {
  if (compIdx < 0 || !g_FNameBlocks) {
    if (debug)
      Log("  [FNAME ERR] compIdx < 0 or g_FNameBlocks null");
    return "";
  }

  int32_t block = compIdx >> 16;
  int32_t offset = compIdx & 0xFFFF;
  if (block < 0 || block >= 8192) {
    if (debug)
      Log("  [FNAME ERR] block out of bounds: %d", block);
    return "";
  }

  uint8_t *blockPtr = g_FNameBlocks[block];
  if (!IsValidPtr(reinterpret_cast<uintptr_t>(blockPtr))) {
    if (debug)
      Log("  [FNAME ERR] blockPtr invalid: 0x%llX (block=%d)",
          reinterpret_cast<uintptr_t>(blockPtr), block);
    return "";
  }

  uint8_t *entryPtr = blockPtr + static_cast<size_t>(offset) * 2;
  if (!IsValidPtr(reinterpret_cast<uintptr_t>(entryPtr))) {
    if (debug)
      Log("  [FNAME ERR] entryPtr invalid: 0x%llX (offset=%d)",
          reinterpret_cast<uintptr_t>(entryPtr), offset);
    return "";
  }

  uint16_t header = *reinterpret_cast<uint16_t *>(entryPtr);
  bool isWide = (header & 1) != 0;
  int32_t len = header >> 6;
  if (isWide || len <= 0 || len > 1024) {
    if (debug)
      Log("  [FNAME ERR] header bad: isWide=%d, len=%d, header=0x%04X",
          isWide, len, header);
    return "";
  }

  return std::string(reinterpret_cast<const char *>(entryPtr + 2), len);
}

static std::string GetObjectFName(void *obj, bool debug = false) {
  if (!obj || !IsValidPtr(reinterpret_cast<uintptr_t>(obj)))
    return "";
  int32_t idx = *reinterpret_cast<int32_t *>(
      reinterpret_cast<uintptr_t>(obj) + BypassOffsets::UObject_Name);
  if (debug)
    Log("  [FNAME DBG] Object 0x%llX -> idx=%d (0x%X)",
        reinterpret_cast<uintptr_t>(obj), idx, idx);
  return ResolveFName(idx, debug);
}

// ----------------------------------------------------------------------------
// Cache UFunction pointers
// ----------------------------------------------------------------------------
static void CacheUFunctionPointers() {
  if (!DiscoverFNameBlocks()) {
    Log("FAILED to init FName parser. UFunctions will be missing!");
    return;
  }

  uintptr_t gobjectsAddr = ResolveGObjects();
  if (!IsValidPtr(gobjectsAddr))
    return;

  uintptr_t chunksPtr = *reinterpret_cast<uintptr_t *>(gobjectsAddr);
  int32_t numElements =
      *reinterpret_cast<int32_t *>(gobjectsAddr + 0x14);
  int32_t numChunks =
      *reinterpret_cast<int32_t *>(gobjectsAddr + 0x18);

  if (!IsValidPtr(chunksPtr) || numElements <= 0 || numChunks <= 0)
    return;

  Log("Caching UFunction pointers (scanning %d objects)...", numElements);

  // Find UFunction class
  void *ufunctionClass = nullptr;
  for (int32_t i = 1; i < numElements && !ufunctionClass; i++) {
    int32_t cIdx = i / 0x10000;
    int32_t inCIdx = i % 0x10000;
    if (cIdx >= numChunks)
      break;

    uintptr_t chunkPtrAddr = chunksPtr + cIdx * sizeof(uintptr_t);
    if (!IsValidPtr(chunkPtrAddr))
      continue;
    uintptr_t chunk = *reinterpret_cast<uintptr_t *>(chunkPtrAddr);
    if (!IsValidPtr(chunk))
      continue;

    uintptr_t objAddr = *reinterpret_cast<uintptr_t *>(chunk + inCIdx * 0x18);
    if (!IsValidPtr(objAddr))
      continue;

    std::string name = GetObjectFName(reinterpret_cast<void *>(objAddr));
    if (name == "Function") {
      uintptr_t classPtr =
          *reinterpret_cast<uintptr_t *>(objAddr + BypassOffsets::UObject_Class);
      if (IsValidPtr(classPtr)) {
        std::string className =
            GetObjectFName(reinterpret_cast<void *>(classPtr));
        if (className == "Class") {
          ufunctionClass = reinterpret_cast<void *>(objAddr);
          Log("Found UFunction class at 0x%llX", objAddr);
        }
      }
    }
  }

  if (!ufunctionClass) {
    Log("WARNING: Could not find UFunction class. Falling back to name-only.");
  }

  int dbgCount = 0;
  int totalFunctions = 0;

  for (int32_t i = 1; i < numElements; i++) {
    int32_t cIdx = i / 0x10000;
    int32_t inCIdx = i % 0x10000;
    if (cIdx >= numChunks)
      break;

    uintptr_t chunkPtrAddr = chunksPtr + cIdx * sizeof(uintptr_t);
    if (!IsValidPtr(chunkPtrAddr))
      continue;
    uintptr_t chunk = *reinterpret_cast<uintptr_t *>(chunkPtrAddr);
    if (!IsValidPtr(chunk))
      continue;

    uintptr_t objAddr = *reinterpret_cast<uintptr_t *>(chunk + inCIdx * 0x18);
    if (!IsValidPtr(objAddr))
      continue;

    if (ufunctionClass) {
      uintptr_t objClass =
          *reinterpret_cast<uintptr_t *>(objAddr + BypassOffsets::UObject_Class);
      if (reinterpret_cast<void *>(objClass) != ufunctionClass)
        continue;
      totalFunctions++;
    }

    bool doDebug = (dbgCount < 10);
    std::string name = GetObjectFName(reinterpret_cast<void *>(objAddr), doDebug);
    if (name.empty()) {
      if (doDebug) {
        Log("DEBUG FAILED resolving name for obj 0x%llX", objAddr);
        dbgCount++;
      }
      continue;
    }

    if (dbgCount < 10) {
      Log("DEBUG UFunction: [%s] @ 0x%llX", name.c_str(), objAddr);
      dbgCount++;
    }

    if (name == "KickSoccerBall")
      g_func_KickSoccerBall = reinterpret_cast<void *>(objAddr);
    else if (name == "HeaderSoccerBall")
      g_func_HeaderSoccerBall = reinterpret_cast<void *>(objAddr);
    else if (name == "SetStaminaClient")
      g_func_SetStaminaClient = reinterpret_cast<void *>(objAddr);
    else if (name == "SetStaminaClientReliable")
      g_func_SetStaminaClientReliable = reinterpret_cast<void *>(objAddr);
    else if (name.find("SetSpeed") != std::string::npos &&
               name.find("Accel") != std::string::npos)
      g_func_SetSpeedAccelClient = reinterpret_cast<void *>(objAddr);
    else if (name.find("ReduceStamina") != std::string::npos)
      g_func_ReduceStamina = reinterpret_cast<void *>(objAddr);
    else if (name == "StartKickChargeHold")
      g_func_StartKickChargeHold = reinterpret_cast<void *>(objAddr);
  }

  Log("Total UFunctions found: %d", totalFunctions);
  Log("  KickSoccerBall:        %s",
      g_func_KickSoccerBall ? "FOUND" : "MISSING");
  Log("  HeaderSoccerBall:      %s",
      g_func_HeaderSoccerBall ? "FOUND" : "MISSING");
  Log("  SetStaminaClient:      %s",
      g_func_SetStaminaClient ? "FOUND" : "MISSING");
  Log("  SetStaminaReliable:    %s",
      g_func_SetStaminaClientReliable ? "FOUND" : "MISSING");
  Log("  SetSpeedAccelClient:   %s",
      g_func_SetSpeedAccelClient ? "FOUND" : "MISSING");
  Log("  ReduceStamina:         %s",
      g_func_ReduceStamina ? "FOUND" : "MISSING");
  Log("  StartKickChargeHold:   %s",
      g_func_StartKickChargeHold ? "FOUND" : "MISSING");
}

// ----------------------------------------------------------------------------
// ProcessEvent hook implementation
// ----------------------------------------------------------------------------
static volatile long g_hookCallCount = 0;

static void ProcessEventHook(void *thisPtr, void *Function, void *Parms) {
  long count = InterlockedIncrement(&g_hookCallCount);
  if (g_sharedConfig)
    g_sharedConfig->hookCallCount = static_cast<volatile int32_t>(count);

  if (count % 5000 == 0)
    Log("HOOK ALIVE: %ld calls processed", count);

  if (!thisPtr || !Function) {
    if (g_usingVMTShadow) {
      // Call original via saved function pointer
      g_originalProcessEvent(thisPtr, Function, Parms);
    } else {
      g_originalProcessEvent(thisPtr, Function, Parms);
    }
    return;
  }

  // Log first matches
  static bool loggedKick = false;
  static bool loggedStamina = false;
  static bool loggedSpeed = false;

  if (Function == g_func_KickSoccerBall && !loggedKick) {
    Log(">>> FIRST KickSoccerBall intercepted! Parms=%p", Parms);
    loggedKick = true;
  }
  if (Function == g_func_SetStaminaClient && !loggedStamina) {
    Log(">>> FIRST SetStaminaClient intercepted! Parms=%p", Parms);
    loggedStamina = true;
  }
  if (Function == g_func_SetSpeedAccelClient && !loggedSpeed) {
    Log(">>> FIRST SetSpeedAccelClient intercepted! Parms=%p", Parms);
    loggedSpeed = true;
  }
  if (Function == g_func_StartKickChargeHold)
    Log(">>> StartKickChargeHold intercepted! Parms=%p", Parms);
  if (Function == g_func_ReduceStamina)
    Log(">>> ReduceStamina intercepted (will block if enabled)");

  // --- Kick bypass ---
  if (g_sharedConfig ? g_sharedConfig->kickPowerBypass : true) {
    if (Parms) {
      if (Function == g_func_KickSoccerBall) {
        auto *p = static_cast<KickSoccerBallParams *>(Parms);
        double orig = p->KickPowerInput;
        double mult = g_sharedConfig ? g_sharedConfig->kickPowerMultiplier : 3.0;
        p->KickPowerInput = static_cast<float>(orig * mult);
        if (g_sharedConfig)
          g_sharedConfig->kicksIntercepted++;
      } else if (Function == g_func_HeaderSoccerBall) {
        auto *p = static_cast<HeaderSoccerBallParams *>(Parms);
        double mult = g_sharedConfig ? g_sharedConfig->kickPowerMultiplier : 3.0;
        p->KickPowerInput = static_cast<float>(p->KickPowerInput * mult);
        if (g_sharedConfig)
          g_sharedConfig->kicksIntercepted++;
      } else if (Function == g_func_StartKickChargeHold) {
        auto *p = static_cast<StartKickChargeHoldParams *>(Parms);
        p->HoldingKickChargePower_0 = 1.0f; // instant max charge
        if (g_sharedConfig)
          g_sharedConfig->kicksIntercepted++;
      }
    }
  }

  // --- Stamina bypass ---
  if (g_sharedConfig ? g_sharedConfig->staminaBypass : true) {
    if (Parms &&
        (Function == g_func_SetStaminaClient ||
         Function == g_func_SetStaminaClientReliable)) {
      auto *p = static_cast<SetStaminaClientParams *>(Parms);
      if (g_sharedConfig) {
        g_sharedConfig->serverStamina = p->Stamina_0;
        p->Stamina_0 = static_cast<float>(g_sharedConfig->staminaValue);
        g_sharedConfig->staminaResetBlocked++;
      } else {
        p->Stamina_0 = 100.0f;
      }
    }
  }

  // --- Block ReduceStamina RPC ---
  if (g_sharedConfig ? g_sharedConfig->blockReduceStamina : true) {
    if (Function == g_func_ReduceStamina) {
      if (g_sharedConfig)
        g_sharedConfig->staminaResetBlocked++;
      return; // BLOCKED — do not forward to original
    }
  }

  // --- Speed/acceleration bypass ---
  if (g_sharedConfig ? g_sharedConfig->speedBypass : true) {
    if (Parms && Function == g_func_SetSpeedAccelClient) {
      auto *p = static_cast<SetSpeedAccelerationClientParams *>(Parms);
      if (g_sharedConfig) {
        g_sharedConfig->serverSpeed = p->Speed;
        g_sharedConfig->serverAcceleration = p->Acceleration;

        double newSpd = p->Speed * g_sharedConfig->speedMultiplier;
        double newAcc = p->Acceleration * g_sharedConfig->accelerationMultiplier;
        if (newSpd > g_sharedConfig->maxSafeSpeed)
          newSpd = g_sharedConfig->maxSafeSpeed;
        if (newAcc > g_sharedConfig->maxSafeAcceleration)
          newAcc = g_sharedConfig->maxSafeAcceleration;

        p->Speed = static_cast<float>(newSpd);
        p->Acceleration = static_cast<float>(newAcc);
        g_sharedConfig->speedSetsIntercepted++;
      }
    }
  }

  // --- Forward to original ---
  if (g_usingVMTShadow) {
    g_originalProcessEvent(thisPtr, Function, Parms);
  } else {
    g_originalProcessEvent(thisPtr, Function, Parms);
  }
}

// ----------------------------------------------------------------------------
// VMT shadowing (stealthy, per-instance)
// ----------------------------------------------------------------------------
static bool InstallVMTShadow(uintptr_t objectAddr) {
  if (!IsValidPtr(objectAddr))
    return false;

  void **originalVTable = *reinterpret_cast<void ***>(objectAddr);
  if (!IsValidPtr(reinterpret_cast<uintptr_t>(originalVTable)))
    return false;

  g_originalVTable = originalVTable;
  g_originalProcessEvent =
      reinterpret_cast<ProcessEvent_t>(originalVTable[BypassOffsets::PROCESSEVENT_VTABLE_INDEX]);
  if (!g_originalProcessEvent)
    return false;

  // Allocate fake vtable (read-write first)
  g_fakeVTable = reinterpret_cast<void **>(
      VirtualAlloc(nullptr, VTABLE_SIZE * sizeof(void *),
                   MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE));
  if (!g_fakeVTable) {
    Log("ERROR: Failed to allocate fake vtable!");
    return false;
  }

  // Copy original vtable
  memcpy(g_fakeVTable, originalVTable, VTABLE_SIZE * sizeof(void *));

  // Make executable-read
  DWORD oldProtect;
  VirtualProtect(g_fakeVTable, VTABLE_SIZE * sizeof(void *),
                 PAGE_EXECUTE_READ, &oldProtect);

  // Install hook into fake vtable
  g_fakeVTable[BypassOffsets::PROCESSEVENT_VTABLE_INDEX] =
      reinterpret_cast<void *>(&ProcessEventHook);

  // Swap object's vptr (offset 0)
  VirtualProtect(reinterpret_cast<LPVOID>(objectAddr), sizeof(void *),
                 PAGE_READWRITE, &oldProtect);
  *reinterpret_cast<void ***>(objectAddr) = g_fakeVTable;
  VirtualProtect(reinterpret_cast<LPVOID>(objectAddr), sizeof(void *),
                 oldProtect, &oldProtect);

  g_usingVMTShadow = true;
  Log("VMT shadow installed on object 0x%llX", objectAddr);
  return true;
}

static void RemoveVMTShadow(uintptr_t objectAddr) {
  if (!g_fakeVTable || !IsValidPtr(objectAddr))
    return;

  void **currentVTable = *reinterpret_cast<void ***>(objectAddr);
  if (currentVTable == g_fakeVTable) {
    DWORD oldProtect;
    VirtualProtect(reinterpret_cast<LPVOID>(objectAddr), sizeof(void *),
                   PAGE_READWRITE, &oldProtect);
    *reinterpret_cast<void ***>(objectAddr) = g_originalVTable;
    VirtualProtect(reinterpret_cast<LPVOID>(objectAddr), sizeof(void *),
                   oldProtect, &oldProtect);
    Log("VMT shadow removed.");
  }

  if (g_fakeVTable) {
    VirtualFree(g_fakeVTable, 0, MEM_RELEASE);
    g_fakeVTable = nullptr;
  }
  g_usingVMTShadow = false;
}

// ----------------------------------------------------------------------------
// Inline detour hook (fallback)
// ----------------------------------------------------------------------------
static uintptr_t FindProcessEventAddress() {
  uintptr_t gobjectsAddr = ResolveGObjects();
  if (!IsValidPtr(gobjectsAddr))
    return 0;

  uintptr_t chunksPtr = *reinterpret_cast<uintptr_t *>(gobjectsAddr);
  if (!IsValidPtr(chunksPtr))
    return 0;

  uintptr_t chunk = *reinterpret_cast<uintptr_t *>(chunksPtr);
  if (!IsValidPtr(chunk))
    return 0;

  for (int i = 1; i < 100; i++) {
    uintptr_t objAddr = *reinterpret_cast<uintptr_t *>(chunk + i * 0x18);
    if (!IsValidPtr(objAddr))
      continue;

    void **vtable = *reinterpret_cast<void ***>(objAddr);
    if (!IsValidPtr(reinterpret_cast<uintptr_t>(vtable)))
      continue;

    for (int idx = 0x40; idx <= 0x55; idx++) {
      uintptr_t funcAddr = reinterpret_cast<uintptr_t>(vtable[idx]);
      if (funcAddr < g_moduleBase || funcAddr > g_moduleBase + g_moduleSize)
        continue;

      uint8_t *b = reinterpret_cast<uint8_t *>(funcAddr);
      bool hasProlog = (b[0] == 0x48 && b[1] == 0x8B && b[2] == 0xC4) ||
                       (b[0] == 0x4C && b[1] == 0x8B && b[2] == 0xDC) ||
                       (b[0] == 0x48 && b[1] == 0x89 && b[2] == 0x5C);
      if (!hasProlog)
        continue;

      bool hasSubRsp = false;
      for (int j = 0; j < 40; j++) {
        if (b[j] == 0x48 && b[j + 1] == 0x81 && b[j + 2] == 0xEC) {
          hasSubRsp = true;
          break;
        }
        if (b[j] == 0x48 && b[j + 1] == 0x83 && b[j + 2] == 0xEC) {
          hasSubRsp = true;
          break;
        }
      }
      if (hasSubRsp) {
        Log("ProcessEvent candidate at VTable[0x%X] = 0x%llX", idx, funcAddr);
        return funcAddr;
      }
    }
  }
  return 0;
}

static bool InstallInlineHook() {
  g_processEventAddr = FindProcessEventAddress();
  if (!g_processEventAddr) {
    Log("ERROR: Could not find ProcessEvent address!");
    return false;
  }

  Log("ProcessEvent found at 0x%llX", g_processEventAddr);

  g_trampoline = reinterpret_cast<uint8_t *>(VirtualAlloc(
      nullptr, 64, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE));
  if (!g_trampoline) {
    Log("ERROR: Failed to allocate trampoline!");
    return false;
  }

  memcpy(g_originalBytes, reinterpret_cast<void *>(g_processEventAddr), 14);
  memcpy(g_trampoline, g_originalBytes, 14);

  // Absolute jump back: FF 25 00 00 00 00 [addr]
  g_trampoline[14] = 0xFF;
  g_trampoline[15] = 0x25;
  *reinterpret_cast<uint32_t *>(g_trampoline + 16) = 0;
  *reinterpret_cast<uintptr_t *>(g_trampoline + 20) = g_processEventAddr + 14;

  g_originalProcessEvent = reinterpret_cast<ProcessEvent_t>(g_trampoline);

  DWORD oldProtect;
  VirtualProtect(reinterpret_cast<void *>(g_processEventAddr), 14,
                 PAGE_EXECUTE_READWRITE, &oldProtect);

  uint8_t *target = reinterpret_cast<uint8_t *>(g_processEventAddr);
  target[0] = 0xFF;
  target[1] = 0x25;
  *reinterpret_cast<uint32_t *>(target + 2) = 0;
  *reinterpret_cast<uintptr_t *>(target + 6) =
      reinterpret_cast<uintptr_t>(&ProcessEventHook);

  VirtualProtect(reinterpret_cast<void *>(g_processEventAddr), 14, oldProtect,
                 &oldProtect);
  FlushInstructionCache(GetCurrentProcess(),
                        reinterpret_cast<void *>(g_processEventAddr), 14);

  g_usingVMTShadow = false;
  Log("Inline hook installed at 0x%llX", g_processEventAddr);
  return true;
}

static void RemoveInlineHook() {
  if (g_processEventAddr && g_originalBytes[0] != 0) {
    DWORD oldProtect;
    VirtualProtect(reinterpret_cast<void *>(g_processEventAddr), 14,
                   PAGE_EXECUTE_READWRITE, &oldProtect);
    memcpy(reinterpret_cast<void *>(g_processEventAddr), g_originalBytes, 14);
    VirtualProtect(reinterpret_cast<void *>(g_processEventAddr), 14, oldProtect,
                   &oldProtect);
    FlushInstructionCache(GetCurrentProcess(),
                          reinterpret_cast<void *>(g_processEventAddr), 14);
    Log("Inline hook removed.");
  }
  if (g_trampoline) {
    VirtualFree(g_trampoline, 0, MEM_RELEASE);
    g_trampoline = nullptr;
  }
}

// ----------------------------------------------------------------------------
// Hook health checks
// ----------------------------------------------------------------------------
static bool VerifyVMTShadow() {
  if (!g_playerActor.load() || !g_fakeVTable)
    return false;
  uintptr_t actor = g_playerActor.load();
  if (!IsValidPtr(actor))
    return false;
  void **vtable = *reinterpret_cast<void ***>(actor);
  return vtable == g_fakeVTable;
}

static bool VerifyInlineHook() {
  if (!g_processEventAddr)
    return false;
  uint8_t *target = reinterpret_cast<uint8_t *>(g_processEventAddr);
  return target[0] == 0xFF && target[1] == 0x25;
}

static bool EnsureHookInstalled(uintptr_t actorAddr) {
  if (g_usingVMTShadow) {
    if (!VerifyVMTShadow()) {
      Log("VMT shadow broken. Reinstalling...");
      RemoveVMTShadow(actorAddr);
      return InstallVMTShadow(actorAddr);
    }
    return true;
  } else {
    if (!VerifyInlineHook()) {
      Log("Inline hook broken. Reinstalling...");
      RemoveInlineHook();
      return InstallInlineHook();
    }
    return true;
  }
}

// ----------------------------------------------------------------------------
// Player actor discovery (for VMT shadow target + direct writes)
// ----------------------------------------------------------------------------
static uintptr_t FindPlayerActor() {
  uintptr_t gobjectsAddr = ResolveGObjects();
  if (!IsValidPtr(gobjectsAddr))
    return 0;

  uintptr_t chunksPtr = *reinterpret_cast<uintptr_t *>(gobjectsAddr);
  if (!IsValidPtr(chunksPtr))
    return 0;
  int32_t numElements =
      *reinterpret_cast<int32_t *>(gobjectsAddr + 0x14);
  if (numElements <= 0 || numElements > 2000000)
    return 0;

  for (int32_t i = 1; i < numElements; i++) {
    int32_t chunkIdx = i / 0x10000;
    int32_t inChunkIdx = i % 0x10000;
    uintptr_t chunkPtrAddr = chunksPtr + chunkIdx * sizeof(uintptr_t);
    if (!IsValidPtr(chunkPtrAddr))
      continue;
    uintptr_t chunk = *reinterpret_cast<uintptr_t *>(chunkPtrAddr);
    if (!IsValidPtr(chunk))
      continue;
    uintptr_t objAddr =
        *reinterpret_cast<uintptr_t *>(chunk + inChunkIdx * 0x18);
    if (!IsValidPtr(objAddr))
      continue;
    uintptr_t classPtr =
        *reinterpret_cast<uintptr_t *>(objAddr + BypassOffsets::UObject_Class);
    if (!IsValidPtr(classPtr))
      continue;

    int32_t propSize = *reinterpret_cast<int32_t *>(
        classPtr + BypassOffsets::UStruct_PropertiesSize);
    if (propSize == BypassOffsets::POV_Character_ClassSize) {
      double stamina =
          *reinterpret_cast<double *>(objAddr + BypassOffsets::Stamina);
      if (stamina >= 0.0 && stamina <= 200.0)
        return objAddr;
    }
  }
  return 0;
}

// ----------------------------------------------------------------------------
// Background bypass thread
// ----------------------------------------------------------------------------
static DWORD WINAPI BypassThread(LPVOID) {
  // Stealth: hide this thread from debugger
  HideThreadFromDebugger(GetCurrentThread());

  // Stealth: no visible console by default
  // AllocConsole(); SetConsoleTitleA(...);  // disabled for stealth

  Log("PSO Bypass v8 (VMT Shadow + Inline Fallback)");

  g_moduleSize = GetLocalModuleSize(g_moduleBase);

  // Initialize shared-config IPC
  InitSharedConfig();

  // Cache UFunction pointers
  CacheUFunctionPointers();

  // Attempt VMT shadowing first (stealthier), fallback to inline hook
  bool hookInstalled = false;
  uintptr_t actor = FindPlayerActor();
  if (actor && IsValidPtr(actor)) {
    g_playerActor.store(actor);
    Log("Player actor found: 0x%llX", actor);
    hookInstalled = InstallVMTShadow(actor);
  }
  if (!hookInstalled) {
    Log("VMT shadow unavailable. Falling back to inline hook.");
    hookInstalled = InstallInlineHook();
  }

  if (g_sharedConfig)
    g_sharedConfig->hookInstalled = hookInstalled;

  if (!hookInstalled) {
    Log("FATAL: No hook installed. Bypass inactive.");
  } else {
    Log("Bypass active. Hook: %s",
        g_usingVMTShadow ? "VMT Shadow" : "Inline Detour");
  }

  int scanCounter = 0;
  int healthCheckCounter = 0;

  auto WasKeyPressed = [](int vkey) -> bool {
    static bool keyStates[256] = {false};
    bool isDown = (GetAsyncKeyState(vkey) & 0x8000) != 0;
    if (isDown && !keyStates[vkey]) {
      keyStates[vkey] = true;
      return true;
    } else if (!isDown) {
      keyStates[vkey] = false;
    }
    return false;
  };

  while (g_running.load()) {
    // --- Sync runtime config from shared memory ---
    BypassSharedConfig localConfig{}; // defaults
    SyncConfigFromShared(localConfig);

    // --- Hotkeys ---
    if (WasKeyPressed(VK_F1)) {
      localConfig.staminaBypass = !localConfig.staminaBypass;
      if (g_sharedConfig)
        g_sharedConfig->staminaBypass = localConfig.staminaBypass;
      Log("Stamina: %d", localConfig.staminaBypass);
    }
    if (WasKeyPressed(VK_F2)) {
      localConfig.kickPowerBypass = !localConfig.kickPowerBypass;
      if (g_sharedConfig)
        g_sharedConfig->kickPowerBypass = localConfig.kickPowerBypass;
      Log("Kick: %d", localConfig.kickPowerBypass);
    }
    if (WasKeyPressed(VK_F3)) {
      localConfig.speedBypass = !localConfig.speedBypass;
      if (g_sharedConfig)
        g_sharedConfig->speedBypass = localConfig.speedBypass;
      Log("Speed: %d", localConfig.speedBypass);
    }
    if (WasKeyPressed(VK_END)) {
      g_running.store(false);
      continue;
    }

    // --- Periodic hook health check (every ~2.5s at 5ms ticks) ---
    if (++healthCheckCounter >= 500) {
      healthCheckCounter = 0;
      uintptr_t currentActor = g_playerActor.load();
      if (!currentActor || !IsValidPtr(currentActor)) {
        currentActor = FindPlayerActor();
        if (currentActor && IsValidPtr(currentActor))
          g_playerActor.store(currentActor);
      }
      if (currentActor && IsValidPtr(currentActor)) {
        EnsureHookInstalled(currentActor);
      } else if (!g_usingVMTShadow) {
        // No actor, but inline hook doesn't need one — just verify
        VerifyInlineHook();
      }
    }

    // --- Refresh actor scan periodically ---
    uintptr_t actor = g_playerActor.load();
    if (!actor || scanCounter++ > 500) {
      scanCounter = 0;
      uintptr_t newActor = FindPlayerActor();
      if (newActor && newActor != actor) {
        g_playerActor.store(newActor);
        actor = newActor;
        Log("Player actor refreshed: 0x%llX", actor);
        // Re-install VMT shadow on new actor if using VMT mode
        if (g_usingVMTShadow) {
          RemoveVMTShadow(actor); // best-effort cleanup on old
          InstallVMTShadow(actor);
        }
      }
    }

    // --- Direct memory writes on player actor ---
    if (actor && IsValidPtr(actor)) {
      if (localConfig.acResetBypass) {
        int32_t jitter = JitteredCounter(localConfig.acCounterJitterMax);
        *reinterpret_cast<int32_t *>(actor + BypassOffsets::SpeedFailed) = jitter;
        *reinterpret_cast<int32_t *>(actor + BypassOffsets::TouchDecelFailed) = jitter;
        *reinterpret_cast<int32_t *>(actor + BypassOffsets::AccelerationFailed) = jitter;
        *reinterpret_cast<int32_t *>(actor + BypassOffsets::MaxAccelerationFailed) = jitter;
        *reinterpret_cast<int32_t *>(actor + BypassOffsets::TimelinesFailed) = jitter;
        *reinterpret_cast<int32_t *>(actor + BypassOffsets::CameraFailed) = jitter;
        *reinterpret_cast<int32_t *>(actor + BypassOffsets::CallbacksFailed) = jitter;
      }

      if (localConfig.staminaBypass) {
        *reinterpret_cast<double *>(actor + BypassOffsets::Stamina) =
            localConfig.staminaValue;
        *reinterpret_cast<bool *>(actor + BypassOffsets::StaminaCooldown) = false;
      }
    }

    // Jittered sleep: 4–12 ms to avoid fixed-rate detection
    DWORD jitterSleep = 4 + (GetTickCount64() % 9);
    Sleep(jitterSleep);
  }

  // Cleanup
  if (g_usingVMTShadow) {
    uintptr_t actor = g_playerActor.load();
    if (actor && IsValidPtr(actor))
      RemoveVMTShadow(actor);
  } else {
    RemoveInlineHook();
  }

  if (g_sharedConfig) {
    UnmapViewOfFile(g_sharedConfig);
    g_sharedConfig = nullptr;
  }
  if (g_configMap) {
    CloseHandle(g_configMap);
    g_configMap = nullptr;
  }

  FreeLibraryAndExitThread(g_dllModule, 0);
  return 0;
}

// ----------------------------------------------------------------------------
// DllMain
// ----------------------------------------------------------------------------
BOOL APIENTRY DllMain(HMODULE hModule, DWORD reason, LPVOID reserved) {
  if (reason == DLL_PROCESS_ATTACH) {
    DisableThreadLibraryCalls(hModule);
    g_dllModule = hModule;
    g_moduleBase = reinterpret_cast<uintptr_t>(GetModuleHandleW(nullptr));
    CreateThread(nullptr, 0, BypassThread, nullptr, 0, nullptr);
  }
  return TRUE;
}